import os
import argparse

def get_files_from_path(path):
    """读取文件夹，返回所有图片文件的完整路径列表"""
    ret = []
    for root, dirs, files in os.walk(path):
        for filespath in files:
            if filespath.endswith(('.png', '.jpg', '.jpeg')):
                ret.append(os.path.join(root, filespath))
    return sorted(ret)

def create_flist(image_dir, output_file):
    """创建文件列表（flist）"""
    files = get_files_from_path(image_dir)
    with open(output_file, 'w') as f:
        for file_path in files:
            f.write(file_path + '\n')
    print(f"Created flist: {output_file} with {len(files)} files")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--images', type=str, required=True, help='path of images directory')
    parser.add_argument('--sketches', type=str, required=True, help='path of sketches directory')
    parser.add_argument('--output_dir', type=str, required=True, help='output directory for flist files')
    args = parser.parse_args()

    # 创建输出目录
    os.makedirs(args.output_dir, exist_ok=True)

    # 创建图像文件列表
    image_flist = os.path.join(args.output_dir, 'train_images.flist')
    create_flist(args.images, image_flist)

    # 创建草图文件列表
    sketch_flist = os.path.join(args.output_dir, 'train_sketches.flist')
    create_flist(args.sketches, sketch_flist)

    print(f"\nFlist files created in: {args.output_dir}")
    print(f"  - Images: {image_flist}")
    print(f"  - Sketches: {sketch_flist}")
