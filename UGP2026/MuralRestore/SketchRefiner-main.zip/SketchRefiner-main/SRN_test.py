import argparse
import random
import os
import cv2
import sys
import numpy as np
from PIL import Image

import torch

from SRN_src.utils import RandomDeformSketch, binary_value
from SRN_src.SRN_network import RegistrationModule, EnhancementModule


def parse_args():
    parser = argparse.ArgumentParser(description='Configuration of sketch refinement network')

    parser.add_argument('--images', default='', type=str, help='path of images')
    parser.add_argument('--masks', default='', type=str, help='path prefix of masks')
    parser.add_argument('--edge_prefix', default='', type=str, help='path prefix of edges')
    parser.add_argument('--sketch_prefix', default='', type=str, help='path prefix of sketches')
    parser.add_argument('--size', default=256, type=int, help='image resolution for testing')
    parser.add_argument('--output', default='', type=str, help='path of output')
    parser.add_argument('--num_samples', type=int, help='number of testing images')
    parser.add_argument('--RM_checkpoint', default='', type=str, help='checkpoint path of registration module')
    parser.add_argument('--EM_checkpoint', default='', type=str, help='checkpoint path of enhancement module')

    args = parser.parse_args()

    return args


def get_files_from_path(path):
    ret = []
    for root, dirs, files in os.walk(path):
        for filespath in files:
            ret.append(os.path.join(root, filespath))
    return ret


def get_files_from_txt(path):

    file_list = []
    f = open(path)
    for line in f.readlines():
        line = line.strip("\n")
        file_list.append(line)
        sys.stdout.flush()
    f.close()

    return file_list


def read_image_with_pil(img_path):
    """使用PIL读取图像，支持CMYK格式，确保返回RGB 3通道图像"""
    pil_img = Image.open(img_path)
    if pil_img.mode == 'CMYK':
        pil_img = pil_img.convert('RGB')
    elif pil_img.mode != 'RGB':
        pil_img = pil_img.convert('RGB')
    return np.array(pil_img)


def visualize(data, keys, path):

        filename = data['filename']

        if not os.path.exists(path):
            os.makedirs(path)

        result_path = os.path.join(path, 'results')
        if not os.path.exists(result_path):
            os.makedirs(result_path)

        refined_sketch = data['em_out']
        refined_sketch = torch.cat([refined_sketch, refined_sketch, refined_sketch], dim=0)
        refined_sketch = refined_sketch.permute(1, 2, 0)
        refined_sketch *= 255.
        refined_sketch = refined_sketch.cpu().detach().numpy().astype(np.uint8)

        Image.fromarray(refined_sketch).save(os.path.join(result_path, filename))

        data_list = []

        for key in keys:
            item = data[key]
            if item.size(0) == 1:
                item = torch.cat([item, item, item], dim=0)
            item = item[:, :, :,].permute(1, 2, 0)
            item = (item * 255.).cpu().detach().numpy().astype(np.uint8)
            data_list.append(item)

        sample = np.concatenate(data_list, axis=1)

        Image.fromarray(sample).save(os.path.join(path, filename))


if __name__ == '__main__':

    configs = parse_args()
    count = 0

    max_move = random.randint(30, 100)
    deform_func = RandomDeformSketch(configs.size)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    registration_module = RegistrationModule().to(device)
    enhancement_module = EnhancementModule().to(device)

    registration_module.load_state_dict(torch.load(configs.RM_checkpoint)['parameters'])
    enhancement_module.load_state_dict(torch.load(configs.EM_checkpoint)['parameters'])

    image_flist = sorted(get_files_from_path(configs.images))
    mask_flist = sorted(get_files_from_path(configs.masks))

    for i in range(configs.num_samples):
        image = read_image_with_pil(image_flist[i])

        file_name = os.path.basename(image_flist[i])
        file_name = file_name.split('.')[0] + '.png'

        mask_path = os.path.join(configs.masks, file_name)
        edge_path = os.path.join(configs.edge_prefix, file_name)
        sketch_path = os.path.join(configs.sketch_prefix, file_name)

        mask = read_image_with_pil(mask_path)
        edge = read_image_with_pil(edge_path)
        sketch = read_image_with_pil(sketch_path)

        if mask is None:
            print(f"Warning: Cannot read mask file: {mask_path}, skipping...")
            continue
        if edge is None:
            print(f"Warning: Cannot read edge file: {edge_path}, skipping...")
            continue
        if sketch is None:
            print(f"Warning: Cannot read sketch file: {sketch_path}, skipping...")
            continue

        image = cv2.resize(image, (configs.size, configs.size))
        mask = cv2.resize(mask, (configs.size, configs.size))
        sketch = cv2.resize(sketch, (configs.size, configs.size))
        edge = cv2.resize(edge, (configs.size, configs.size))

        image = image / 255.
        mask = mask / 255.
        edge = edge / 255.
        sketch = sketch / 255.

        image = torch.from_numpy(image.astype(np.float32)).permute(2, 0, 1).contiguous()
        mask = torch.from_numpy(mask.astype(np.float32)).permute(2, 0, 1).contiguous()
        edge = torch.from_numpy(edge.astype(np.float32)).permute(2, 0, 1).contiguous()
        sketch = torch.from_numpy(sketch.astype(np.float32)).permute(2, 0, 1).contiguous()

        image = image.to(device)
        mask = mask.to(device)
        edge = edge.to(device)
        sketch = sketch.to(device)

        mask = torch.sum(mask / 3, dim=0, keepdim=True)
        sketch = torch.sum(sketch / 3, dim=0, keepdim=True)
        edge = torch.sum(edge / 3, dim=0, keepdim=True)

        thresh = random.uniform(0.65, 0.75)
        mask = binary_value(mask, 0.5)
        sketch = binary_value(sketch, thresh)
        edge = binary_value(edge, thresh)

        visualize_sketch = sketch

        masked_img = image * (1 - mask) + mask
        sketch = sketch * mask + edge * (1 - mask)

        rm_in = torch.cat([masked_img, mask, sketch], dim=0).unsqueeze(0)
        rm_out = registration_module(rm_in).squeeze(0)

        thresh = torch.mean(rm_out)
        em_in = binary_value(rm_out, thresh)

        em_in = em_in * mask + edge * (1 - mask)
        visualize_em_in = em_in.detach()

        em_out = enhancement_module(em_in.unsqueeze(0)).squeeze(0)
        em_out = torch.clamp(em_out, 0.0, 1.0)
        em_out = em_out * mask + edge * (1 - mask)
        em_out = binary_value(em_out, torch.mean(em_out))

        data = {
            'filename': file_name,
            'image': image,
            'masked_img': masked_img,
            'rm_in': visualize_sketch * mask + (1 - mask) * edge,
            'rm_out': rm_out,
            'edge': edge,
            'em_in': rm_out * mask + (1 - mask) * edge,
            'em_out': em_out * mask + (1 - mask) * edge,
        }

        visualize(data, ['image', 'masked_img', 'rm_in', 'edge', 'em_in', 'em_out'], configs.output)

        count += 1
        print(f"Progress completed: {count}/{configs.num_samples}")