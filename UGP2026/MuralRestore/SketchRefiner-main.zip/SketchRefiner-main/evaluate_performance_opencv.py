import cv2
import numpy as np
import os

def calculate_psnr(original, restored):
    """计算PSNR"""
    mse = np.mean((original - restored) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel = 255.0
    psnr = 20 * np.log10(max_pixel / np.sqrt(mse))
    return psnr

def calculate_ssim(original, restored):
    """计算SSIM"""
    C1 = (0.01 * 255) ** 2
    C2 = (0.03 * 255) ** 2
    
    # 转换为灰度图
    if len(original.shape) == 3:
        original_gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
        restored_gray = cv2.cvtColor(restored, cv2.COLOR_BGR2GRAY)
    else:
        original_gray = original
        restored_gray = restored
    
    # 高斯模糊
    mu1 = cv2.GaussianBlur(original_gray, (11, 11), 1.5)
    mu2 = cv2.GaussianBlur(restored_gray, (11, 11), 1.5)
    
    # 计算方差和协方差
    sigma1 = cv2.GaussianBlur(original_gray ** 2, (11, 11), 1.5) - mu1 ** 2
    sigma2 = cv2.GaussianBlur(restored_gray ** 2, (11, 11), 1.5) - mu2 ** 2
    sigma12 = cv2.GaussianBlur(original_gray * restored_gray, (11, 11), 1.5) - mu1 * mu2
    
    # 计算SSIM
    ssim_map = ((2 * mu1 * mu2 + C1) * (2 * sigma12 + C2)) / ((mu1 ** 2 + mu2 ** 2 + C1) * (sigma1 + sigma2 + C2))
    return np.mean(ssim_map)

# 图像路径
test_dir = 'test/images'
restored_dir = 'output/SIN/test/inpainted_with_refined_sketch'

# 确保目录存在
if not os.path.exists(test_dir):
    print(f"Error: {test_dir} not found")
    exit(1)

if not os.path.exists(restored_dir):
    print(f"Error: {restored_dir} not found")
    exit(1)

# 评估结果
results = []

# 遍历所有图像
for filename in os.listdir(test_dir):
    if filename.endswith('.png') or filename.endswith('.jpg'):
        # 原始图像路径
        original_path = os.path.join(test_dir, filename)
        # 修复后图像路径
        restored_path = os.path.join(restored_dir, filename)
        
        # 检查文件是否存在
        if not os.path.exists(restored_path):
            print(f"Warning: {restored_path} not found, skipping...")
            continue
        
        # 读取图像
        original = cv2.imread(original_path)
        restored = cv2.imread(restored_path)
        
        if original is None or restored is None:
            print(f"Warning: Cannot read images for {filename}, skipping...")
            continue
        
        # 确保图像尺寸一致
        if original.shape != restored.shape:
            restored = cv2.resize(restored, (original.shape[1], original.shape[0]))
            print(f"Resized {filename} to match original dimensions")
        
        # 计算PSNR
        psnr = calculate_psnr(original, restored)
        
        # 计算SSIM
        ssim = calculate_ssim(original, restored)
        
        # 存储结果
        results.append({
            'filename': filename,
            'psnr': psnr,
            'ssim': ssim
        })
        
        print(f"{filename}: PSNR = {psnr:.2f}, SSIM = {ssim:.4f}")

# 计算平均值
if results:
    avg_psnr = np.mean([r['psnr'] for r in results])
    avg_ssim = np.mean([r['ssim'] for r in results])
    print(f"\nAverage PSNR: {avg_psnr:.2f}")
    print(f"Average SSIM: {avg_ssim:.4f}")
else:
    print("No images processed")