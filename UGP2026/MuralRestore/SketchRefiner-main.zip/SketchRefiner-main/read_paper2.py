from docx import Document

doc_path = r'f:\InkLayerTEST\论文（2）.docx'

try:
    doc = Document(doc_path)
    
    print("=== 论文（2）.docx 内容预览 ===\n")
    
    # 找到第二章
    chapter_2_found = False
    
    for i, para in enumerate(doc.paragraphs):
        text = para.text.strip()
        
        # 检查是否是第二章开始
        if '第二章' in text or '第2章' in text:
            chapter_2_found = True
            print(f"=== 第二章开始 (段落 {i+1}) ===\n")
        
        # 如果找到第二章，打印内容
        if chapter_2_found:
            if text:
                print(f"段落 {i+1}: {text[:300]}{'...' if len(text) > 300 else ''}\n")
            
            # 检查是否到第三章
            if ('第三章' in text or '第3章' in text) and chapter_2_found:
                print("=== 第二章结束 ===\n")
                break
    
    if not chapter_2_found:
        print("未找到第二章，打印前50段内容：\n")
        for i, para in enumerate(doc.paragraphs[:50]):
            if para.text.strip():
                print(f"段落 {i+1}: {para.text[:200]}{'...' if len(para.text) > 200 else ''}\n")
    
    print("=== 文档检查完成 ===")
    
except Exception as e:
    print(f"读取文档时出错: {e}")
    print("\n请确保已安装python-docx库:")
    print("pip install python-docx")