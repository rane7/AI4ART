import cv2
import numpy as np
from skimage.metrics import peak_signal_noise_ratio, structural_similarity
import os

# 图像路径
test_dir = 'test/images'
restored_dir = 'output/SIN/test/inpainted_with_refined_sketch'

# 确保目录存在
if not os.path.exists(test_dir):
    print(f"Error: {test_dir} not found")
    exit(1)

if not os.path.exists(restored_dir):
    print(f"Error: {restored_dir} not found")
    exit(1)

# 评估结果
results = []

# 遍历所有图像
for filename in os.listdir(test_dir):
    if filename.endswith('.png') or filename.endswith('.jpg'):
        # 原始图像路径
        original_path = os.path.join(test_dir, filename)
        # 修复后图像路径
        restored_path = os.path.join(restored_dir, filename)
        
        # 检查文件是否存在
        if not os.path.exists(restored_path):
            print(f"Warning: {restored_path} not found, skipping...")
            continue
        
        # 读取图像
        original = cv2.imread(original_path)
        restored = cv2.imread(restored_path)
        
        if original is None or restored is None:
            print(f"Warning: Cannot read images for {filename}, skipping...")
            continue
        
        # 确保图像尺寸一致
        if original.shape != restored.shape:
            restored = cv2.resize(restored, (original.shape[1], original.shape[0]))
            print(f"Resized {filename} to match original dimensions")
        
        # 计算PSNR
        psnr = peak_signal_noise_ratio(original, restored)
        
        # 计算SSIM (MSSSIM)
        ssim = structural_similarity(original, restored, channel_axis=2)
        
        # 存储结果
        results.append({
            'filename': filename,
            'psnr': psnr,
            'ssim': ssim
        })
        
        print(f"{filename}: PSNR = {psnr:.2f}, SSIM = {ssim:.4f}")

# 计算平均值
if results:
    avg_psnr = np.mean([r['psnr'] for r in results])
    avg_ssim = np.mean([r['ssim'] for r in results])
    print(f"\nAverage PSNR: {avg_psnr:.2f}")
    print(f"Average SSIM: {avg_ssim:.4f}")
else:
    print("No images processed")