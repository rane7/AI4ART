import cv2
import os
import sys

# 设置数据集路径
data_dir = 'F:\\桌面\\作业\\壁画数字化图像修复方法及实现\\2025-毕设\\敦煌整理素材1374+418\\敦煌白描1——敦煌莫高窟线描稿186张\\test3'

# 列出目录中的文件
files = os.listdir(data_dir)
print(f"目录中的文件数量: {len(files)}")

# 过滤出PNG文件
png_files = [f for f in files if f.endswith('.png')]
print(f"PNG文件数量: {len(png_files)}")

# 检查前5个文件
for i, file in enumerate(png_files[:5]):
    img_path = os.path.join(data_dir, file)
    img = cv2.imread(img_path)
    if img is not None:
        print(f"文件 {file}: 尺寸={img.shape}, 类型={img.dtype}")
    else:
        print(f"文件 {file}: 无法读取")

print("数据检查完成！")