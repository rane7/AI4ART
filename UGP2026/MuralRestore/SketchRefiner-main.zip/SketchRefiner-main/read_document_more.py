from docx import Document

doc_path = r'f:\InkLayerTEST\论文（初）.docx'
doc = Document(doc_path)

print("=== 继续读取更多文档内容 ===\n")

# 读取更多段落
for i, para in enumerate(doc.paragraphs[20:50]):  # 读取第21-50段
    if para.text.strip():
        print(f"段落 {i+21}: {para.text[:300]}{'...' if len(para.text) > 300 else ''}\n")

# 检查是否有图片
print("=== 检查图片 ===\n")
img_count = 0
for rel in doc.part.rels.values():
    if "image" in rel.target_ref:
        img_count += 1
        print(f"图片 {img_count}: {rel.target_ref}")

print(f"\n共发现 {img_count} 张图片")

# 读取表格内容
print("\n=== 表格内容 ===\n")
for i, table in enumerate(doc.tables):
    print(f"表格 {i+1}:")
    for row in table.rows:
        row_text = " | ".join([cell.text.strip() for cell in row.cells])
        print(f"  {row_text}")
    print()