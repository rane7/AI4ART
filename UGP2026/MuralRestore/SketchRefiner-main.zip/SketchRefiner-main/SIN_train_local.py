import argparse
import os
import random
import sys
from shutil import copyfile

import cv2
import numpy as np
import torch
import torch.distributed as dist

from SIN_src.SIN_trainer import *
from SIN_src.config import Config


def get_files_from_path(path):
    """读取文件夹，返回所有图片文件的完整路径列表"""
    ret = []
    for root, dirs, files in os.walk(path):
        for filespath in files:
            if filespath.endswith(('.png', '.jpg', '.jpeg')):
                ret.append(os.path.join(root, filespath))
    return sorted(ret)


def create_flist(image_dir, output_file):
    """创建文件列表（flist）"""
    files = get_files_from_path(image_dir)
    with open(output_file, 'w') as f:
        for file_path in files:
            f.write(file_path + '\n')
    print(f"Created flist: {output_file} with {len(files)} files")
    return len(files)


def main_worker(args):
    # 使用CPU或CUDA
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        print(f"Using CUDA device")
    else:
        print("Using CPU device")

    # load config file
    config = Config(args.config_path)
    config.MODE = 1
    config.nodes = 1
    config.gpus = 1 if torch.cuda.is_available() else 0
    config.GPU_ids = '0'
    config.DDP = False
    config.world_size = 1

    # 设置设备
    config.DEVICE = device

    torch.backends.cudnn.benchmark = True  # cudnn auto-tuner
    cv2.setNumThreads(0)

    # initialize random seed
    torch.manual_seed(config.SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config.SEED)
    np.random.seed(config.SEED)
    random.seed(config.SEED)

    # 创建flist文件
    flist_dir = os.path.join(args.output, 'flist')
    os.makedirs(flist_dir, exist_ok=True)
    
    # 创建图像文件列表
    image_flist_path = os.path.join(flist_dir, 'train_images.flist')
    num_images = create_flist(args.images, image_flist_path)
    
    # 创建草图文件列表
    sketch_flist_path = os.path.join(flist_dir, 'train_sketches.flist')
    num_sketches = create_flist(args.sketches, sketch_flist_path)
    
    print(f"\nFound {num_images} images and {num_sketches} sketches")

    # 更新配置文件中的路径
    config.TRAIN_FLIST = image_flist_path
    config.SKETCH_PATH = sketch_flist_path
    config.OUTPUT_DIR = args.output
    config.PATH = args.output
    
    # 设置批次大小和工作进程数
    if args.batch_size:
        config.BATCH_SIZE = args.batch_size
    if args.num_workers is not None:
        config.num_workers = args.num_workers
    
    # 设置最大迭代次数和保存间隔
    if args.max_iters:
        config.MAX_ITERS = args.max_iters
    if args.save_interval:
        config.SAVE_INTERVAL = args.save_interval

    # build the model and initialize
    model = SINTrainer(config, device, 0)

    # model training
    config.print()
    print('\nstart training...\n')
    model.train()

    print('\nTraining completed!')


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--config_path', type=str, default='./SIN_src/configs/example.yml',
                        help='path of configuration path')
    parser.add_argument('--images', type=str, required=True, help='path of training images directory')
    parser.add_argument('--sketches', type=str, required=True, help='path of training sketches directory')
    parser.add_argument('--output', type=str, required=True, help='path of output directory')
    parser.add_argument('--batch_size', type=int, default=2, help='batch size for training')
    parser.add_argument('--num_workers', type=int, default=0, help='number of workers for data loading')
    parser.add_argument('--max_iters', type=int, default=10000, help='maximum number of iterations')
    parser.add_argument('--save_interval', type=int, default=1000, help='interval of saving checkpoints')

    args = parser.parse_args()

    # 创建输出目录
    os.makedirs(args.output, exist_ok=True)

    # 运行训练
    main_worker(args)
