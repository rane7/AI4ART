<div align="center">

# 通过草图精炼实现交互式图像修复

Chang Liu, Shunxin Xu, Jialun Peng, Kaidong Zhang, Dong Liu

[[`Paper`]](https://ieeexplore.ieee.org/abstract/document/10533842/) / [[`Project`]](https://alonzoleeeooo.github.io/SketchRefiner/) / [`Baidu Disk`] [(`Models`)](https://pan.baidu.com/s/1TAqqwHkjnBoDmfxMl0vl6Q?pwd=skre) [(`Test Protocol`)](https://pan.baidu.com/s/1avtBkYaOuxm36X-eoQERrw) / [`Huggingface`] [(`Models`)](https://huggingface.co/AlonzoLeeeooo/SketchRefiner) [(`Test Protocol`)](https://huggingface.co/datasets/AlonzoLeeeooo/sketchrefiner-real-world-test-protocol) / [[`Google Drive`]](https://drive.google.com/drive/folders/1xOeKO4f6tfco2AV0V_0EgJzYThOFb3kp?usp=drive_link) / [`Interactive Demo`]
</div>


*(下载真实世界测试协议的密码：rwtp)*

<!-- omit in toc -->
# 目录
- [<u>1. 新闻</u>](#news)
- [<u>2. 引用</u>](#citation)
- [<u>3. 概述</u>](#overview)
- [<u>4. 待办事项</u>](#to-do-lists)
- [<u>5. 先决条件</u>](#prerequisites)
- [<u>6. 使用方法</u>](#usage)
- [<u>7. 定性比较</u>](#qualitative-comparisons)
- [<u>8. 许可证</u>](#license)
- [<u>9. 致谢</u>](#acknowledgements)
- [<u>10. 常见问题</u>](#frequently-asked-questions)
- [<u>11. 分支和星标历史</u>](#forked-and-star-history)


<!-- omit in toc -->
# 🔥新闻
- [2025年12月11日] 我们的论文《StableV2V: Stablizing Shape Consistency in Video-to-Video Editing》已被TCSVT 2025接受！
- [8月7日] 我们目前正在修改当前代码库（ICCV版本）以对应我们已接受论文（TMM版本）的版本。代码将在不久的将来逐步更新。
- [5月17日] 我们的论文《Towards Interactive Image Inpainting via Robust Sketch Refinement》已被TMM 2024接受！


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 引用
如果您发现我们的工作具有启发性或提出的数据集对您有用，请引用我们的TMM 2024论文。
```tex
@ARTICLE{liu-etal-2024-sketchrefiner,
  author={Liu, Chang and Xu, Shunxin and Peng, Jialun and Zhang, Kaidong and Liu, Dong},
  journal={IEEE Transactions on Multimedia}, 
  title={Towards Interactive Image Inpainting via Robust Sketch Refinement}, 
  year={2024},
  pages={1-15},
}
```

[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 概述
![tissor](github_materials/teasor.jpg)
图像修复的一个难题是在损坏区域恢复复杂结构。这激发了交互式图像修复，它利用额外提示，例如草图，来辅助修复过程。草图对最终用户简单直观，但同时具有自由形式和大量随机性。这种随机性可能会混淆修复模型，并在完成图像中引起严重伪影。为了解决这个问题，我们提出了一种名为SketchRefiner的两阶段图像修复方法。在第一阶段，我们提出使用交叉相关损失函数以粗到细的方式稳健地校准和精炼用户提供的草图。在第二阶段，我们学习从抽象草图中提取潜在空间的特征，并调节修复过程。我们还提出了一种算法来自动模拟真实草图，并构建了一个测试协议来评估不同方法在真实应用中的表现。在公共数据集上的实验结果表明，SketchRefiner有效地利用草图信息，并消除了由于自由形式草图引起的伪影。我们的方法在定性和定量上始终优于最先进的基线，同时在真实世界应用中显示出巨大潜力。


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 待办事项
- [ ] SketchRefiner的在线演示。
- [x] SketchRefiner的官方安装和使用说明。
- [x] SketchRefiner的训练代码。
- [x] SketchRefiner的测试代码。
- [x] 提出的基于草图的测试协议。
- [x] 预训练模型权重。
- 定期维护


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 先决条件
要安装环境，您可以执行以下脚本：
```bash
conda create -n sketchrefiner python=3.6
conda activate sketchrefiner
pip install torch==1.9.0+cu111 torchvision==0.10.0+cu111 torchaudio==0.9.0 -f https://download.pytorch.org/whl/torch_stable.html
pip install opencv-python
```

要利用HRF损失来训练模型，请下载[LaMa](https://github.com/advimman/lama)提供的预训练模型。您可以通过执行以下命令行下载模型：
```bash
mkdir -p ade20k/ade20k-resnet50dilated-ppm_deepsup/
wget -P ade20k/ade20k-resnet50dilated-ppm_deepsup/ http://sceneparsing.csail.mit.edu/model/pytorch/ade20k-resnet50dilated-ppm_deepsup/encoder_epoch_20.pth
```
注意，`ade20k`文件夹位于`SIN_src/models/ade20k`。


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 使用方法
<!-- omit in toc -->
## 数据预处理
在训练所有网络之前，您需要首先按照以下程序准备所有数据：
1. 下载[ImageNet](https://www.image-net.org/)、[CelebA-HQ](https://github.com/tkarras/progressive_growing_of_gans)和[Places2](http://places2.csail.mit.edu/download.html)数据集。假设这些数据下载到`datasets/dataset_name`。
2. 使用边缘检测器[BDCN](https://github.com/pkuCactus/BDCN)从`datasets`中的地面真实图像提取边缘图。假设生成的边缘图位于`datasets/dataset_name/edges`。
3. 运行`scripts/make_deform_sketch.py`来生成用于训练的变形草图。我们提供以下示例命令行：
```bash
# 从检测到的边缘图生成变形草图
python scripts/make_deform_sketch.py
      --edge datasets/dataset_name/edges
      --output datasets/dataset_name/sketches
```
您可以调整`--grid_size`、`--filter_size`和`--max_move`来控制扭曲边缘图的幅度。您可以通过调整`--num_samples`来选择生成的草图数量。


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
## 训练
<!-- omit in toc -->
### 1. 训练草图精炼网络（SRN）
在训练SketchRefiner的修复网络之前，您需要首先训练提出的草图精炼网络（SRN）。我们演示以下示例命令行：

```bash
# 训练注册模块（RM）
python SRN_train.py
      --images /path/to/images
      --edges_prefix /path/to/edge
      --output /path/to/output/dir
      
# 训练增强模块（EM）
python SRN_train.py
      --images /path/to/images/
      --edges_prefix /path/to/edge/
      --output /path/to/output/dir
      --train_EM
      --RM_checkpoint /path/to/model/weights/of/RM
```

如果您需要在训练期间评估模型，请确保分配`val_interval > 0`并配置`images_val`、`masks_val`、`sketches_prefix_val`、`edges_prefix_val`的路径。

<!-- omit in toc -->
### 2. 训练草图调制修复网络（SIN）
SRN训练完成后，您可以通过执行以下命令开始训练SIN：
```bash
python SIN_train.py
      --config_path /path/to/config
      --GPU_ids gpu_id
```
确保修改配置文件中相应的行以包含训练数据的路径。我们在`SIN_src/configs/example.yml`中放置了一个示例配置文件。


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
## 推理
<!-- omit in toc -->
### 3. 精炼输入草图
在推理期间，您需要首先精炼输入草图并将其本地保存，通过运行：
```bash
python SRN_test.py
      --images /path/to/test/source/images
      --masks /path/to/test/masks
      --edge_prefix /path/to/detected/edges
      --sketch_prefix /path/to/input/sketches
      --output /path/to/output/dir
      --RM_checkpoint /path/to/RM/checkpoint
      --EM_checkpoint /path/to/EM/checkpoint
```
精炼的草图将保存在分配的`output`路径。

<!-- omit in toc -->
### 4. 使用精炼草图修复损坏图像
现在您可以使用来自SRN的精炼草图修复损坏图像，通过运行：
```bash
python SIN_test.py
      --config_path /path/to/config/path
      --GPU_ids gpu_id
      --images /path/to/source/images
      --masks /path/to/masks
      --edges /path/to/detected/edges
      --sketches /path/to/input/sketches
      --refined_sketches /path/to/refined/sketches
      --output /path/to/output/dir/
      --checkpoint /path/to/model/weights/of/SIM
      --num_samples maximum_samples
```
边缘使用bdcn检测，您可以在[此处](https://github.com/pkuCactus/BDCN)参考他们的代码。


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
## 预训练模型权重
我们在CelebA-HQ、Places2和ImageNet上发布了SketchRefiner的预训练模型权重，可在[此处](https://pan.baidu.com/s/1TAqqwHkjnBoDmfxMl0vl6Q?pwd=skre)（密码：skre）参考。

<!-- omit in toc -->
## 真实世界测试协议
我们发布了精心策划的真实世界测试协议，目前由26张人脸图像和60张自然图像组成，并带有手动标注的掩码和草图。请注意，当前发布的版本可能会在我们论文最终接受之前进一步修订。您可以在[此处](https://pan.baidu.com/s/1avtBkYaOuxm36X-eoQERrw)（密码：rwtp）下载测试协议。

我们在以下图中提供了一些测试协议的示例。 <details>
<summary>真实世界测试协议示例</summary>

![realworld](github_materials/realworld.jpg)

</details>


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 定性比较
我们在以下图中演示了人脸和自然图像的定性比较。
<details><summary>人脸图像</summary>

![celebahq](github_materials/celebahq.jpg)

</details>

<details><summary>自然图像</summary>

![places](github_materials/places.jpg)

</details>

<details><summary>更多结果</summary>

![more_results](github_materials/more_results.jpg)

</details>


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 许可证
此作品根据MIT许可证授权。详情请见[LICENSE](LICENSE)。


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 致谢
此代码库大量修改自[ZITS](https://github.com/DQiaole/ZITS_inpainting)。感谢他们的出色实现！


[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 常见问题

<!-- omit in toc -->
## 1. `BDCN`的使用

我们不推荐使用官方`BDCN`代码库，因为其`Python 2`实现可能会与最新库产生一系列错误。
相反，我们在[此仓库](https://github.com/AlonzoLeeeooo/SketchRefiner)（在`data-processing/bdcn-edge-detection`中）提供了一个`Python 3`版本的实现。BDCN的模型权重可在[此链接](https://huggingface.co/AlonzoLeeeooo/LaCon/resolve/main/data-preprocessing/bdcn.pth)获得。请参考仓库文档以获取更多详情。

> 相关问题：[#8](https://github.com/AlonzoLeeeooo/SketchRefiner/issues/8)

<!-- omit in toc -->
## 2. 配置参数的使用

如果您对`argparse`中包装的配置参数的使用有任何疑问，请随时在以下问题中与我们讨论，或[启动新问题](https://github.com/AlonzoLeeeooo/SketchRefiner/issues/new)。

> 相关问题：[#4](https://github.com/AlonzoLeeeooo/SketchRefiner/issues/4), [#5](https://github.com/AlonzoLeeeooo/SketchRefiner/issues/5), [#9](https://github.com/AlonzoLeeeooo/SketchRefiner/issues/9), [#10](https://github.com/AlonzoLeeeooo/SketchRefiner/issues/10)

[<u><small><🎯返回目录></small></u>](#table-of-contents)

<!-- omit in toc -->
# 分支和星标历史

[![Stargazers repo roster for @AlonzoLeeeooo/SketchRefiner](https://reporoster.com/stars/dark/AlonzoLeeeooo/SketchRefiner)](https://github.com/AlonzoLeeeooo/SketchRefiner/stargazers)

[![Forkers repo roster for @AlonzoLeeeooo/SketchRefiner](https://reporoster.com/forks/dark/AlonzoLeeeooo/SketchRefiner)](https://github.com/AlonzoLeeeooo/SketchRefiner/network/members)

<p align="center">
    <a href="https://api.star-history.com/svg?repos=AlonzoLeeeooo/SketchRefiner&type=Date" target="_blank">
        <img width="500" src="https://api.star-history.com/svg?repos=AlonzoLeeeooo/SketchRefiner&type=Date" alt="Star History Chart">
    </a>
<p>


[<u><small><🎯返回目录></small></u>](#table-of-contents)
