import os
import shutil

# 源数据目录
source_dir = 'F:\\桌面\\作业\\壁画数字化图像修复方法及实现\\2025-毕设\\敦煌整理素材1374+418\\敦煌白描1——敦煌莫高窟线描稿186张\\test3'

# 目标数据目录
target_dir = 'f:\\桌面\\作业\\壁画数字化图像修复方法及实现\\SketchRefiner-main\\datasets\\dunhuang\\images'
edge_dir = 'f:\\桌面\\作业\\壁画数字化图像修复方法及实现\\SketchRefiner-main\\datasets\\dunhuang\\edges'

# 确保目标目录存在
os.makedirs(target_dir, exist_ok=True)
os.makedirs(edge_dir, exist_ok=True)

# 复制文件
files = os.listdir(source_dir)
png_files = [f for f in files if f.endswith('.png') and f != '.png']

print(f"开始复制 {len(png_files)} 张图像...")

for i, file in enumerate(png_files):
    source_path = os.path.join(source_dir, file)
    target_path = os.path.join(target_dir, file)
    edge_path = os.path.join(edge_dir, file)
    
    # 复制到图像目录
    shutil.copy2(source_path, target_path)
    # 复制到边缘目录（因为白描图像本身就是边缘图）
    shutil.copy2(source_path, edge_path)
    
    if (i + 1) % 20 == 0:
        print(f"已复制 {i + 1}/{len(png_files)} 张图像")

print(f"数据准备完成！共复制 {len(png_files)} 张图像到训练目录")