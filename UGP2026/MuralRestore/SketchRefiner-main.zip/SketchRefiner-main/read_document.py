from docx import Document

# 读取Word文档
doc_path = r'f:\InkLayerTEST\论文（初）.docx'

try:
    doc = Document(doc_path)
    
    print("文档内容预览：\n")
    
    # 遍历文档段落
    for i, para in enumerate(doc.paragraphs[:20]):  # 只读取前20段
        if para.text.strip():
            print(f"段落 {i+1}: {para.text[:200]}{'...' if len(para.text) > 200 else ''}\n")
    
    # 检查是否有表格
    if doc.tables:
        print(f"\n文档包含 {len(doc.tables)} 个表格")
        for i, table in enumerate(doc.tables):
            print(f"表格 {i+1}: {len(table.rows)} 行 x {len(table.columns)} 列")
            
    print("\n--- 文档检查完成 ---")
    
except Exception as e:
    print(f"读取文档时出错: {e}")
    print("\n请确保已安装python-docx库:")
    print("pip install python-docx")