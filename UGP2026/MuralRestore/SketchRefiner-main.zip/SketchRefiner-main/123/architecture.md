# 壁画数字化修复系统架构

```mermaid
flowchart TD 
     %% =============== 全局样式设定 =============== 
     classDef bdccn fill:#16A34A,stroke:#059669,color:white,font-weight:bold; 
     classDef inklayer fill:#D97706,stroke:#B45309,color:white,font-weight:bold; 
     classDef sketchrefiner fill:#2563EB,stroke:#1D4ED8,color:white,font-weight:bold; 
     classDef user fill:#7C3AED,stroke:#6D28D9,color:white,font-weight:bold; 
     classDef data fill:#0891B2,stroke:#0E7490,color:white,font-weight:bold; 
 
     %% =============== 核心模块 =============== 
     subgraph BDCN["BDCN 边缘检测模块\n■ 双向级联结构\n■ 多尺度特征融合"] 
         direction TB 
         BDCN_Input[("原始壁画图像\n.png/.jpg")] --> BDCN_Core["BDCN 模型\n(双向级联+多尺度融合)"] 
         BDCN_Core --> BDCN_Output[("边缘草图\n灰度图")] 
     end 
 
     subgraph InkLayer["InkLayer 批量分割模块\n■ GroundingDINO + SAM\n■ Depth Anything V2"] 
         direction TB 
         InkLayer_Input[("原始壁画图像\n.png/.jpg")] --> Detector["GroundingDINO\n文本引导检测"] 
         Detector --> Segmentor["SAM\n零样本精细分割"] 
         InkLayer_Input --> DepthEstimator["Depth Anything V2\n深度估计"] 
         Segmentor --> InkLayer_Mask[("masks\nPNG, per-region")] 
         Segmentor --> InkLayer_BBox[("bbox.json\n边界框坐标")] 
         DepthEstimator -.-> Segmentor 
     end 
 
     subgraph SketchRefiner["SketchRefiner 修复模块\n■ SRN + SIN 协同架构"] 
         direction LR 
         subgraph SRN["SRN 草图精炼网络"] 
             RM["Registration Module\n(RM)"] --> EM["Enhancement Module\n(EM)"] 
         end 
         subgraph SIN["SIN 草图调制修复网络"] 
             PSE["Partial Sketch Encoder\n(PSE)"] --> TRM["Texture Recovery Module\n(TRM)"] 
         end 
         SRN & SIN --> Fusion["融合修复引擎"] 
         Fusion --> Output[("修复后的壁画图像\n高保真/结构一致/纹理自然")] 
     end 
 
     subgraph User["用户交互端"] 
         User_Sketch[("用户手绘草图\n交互式输入")] 
     end 
 
     %% =============== 数据流向 =============== 
     BDCN_Output -.->|边缘草图\n结构指导| SketchRefiner 
     InkLayer_Mask -.->|分割掩码\n区域定位| SketchRefiner 
     InkLayer_BBox -.->|边界框坐标\n辅助对齐| SketchRefiner 
     User_Sketch -.->|用户草图\n语义指导| SketchRefiner 
     BDCN_Input -->|原始图像| SketchRefiner 
     InkLayer_Input -->|原始图像| SketchRefiner 
 
     %% =============== 样式应用 =============== 
     class BDCN,BDCN_Input,BDCN_Core,BDCN_Output bdccn; 
     class InkLayer,InkLayer_Input,Detector,Segmentor,DepthEstimator,InkLayer_Mask,InkLayer_BBox inklayer; 
     class SketchRefiner,SRN,SIN,RM,EM,PSE,TRM,Fusion,Output sketchrefiner; 
     class User,User_Sketch user; 
     class BDCN_Output,InkLayer_Mask,InkLayer_BBox,User_Sketch,data; 
 
     %% =============== 图例说明（底部注释） =============== 
     linkStyle default stroke:#6B7280,stroke-width:2px,fill:none; 
     classDef legend fill:#F9FAFB,stroke:#E5E7EB,stroke-width:1px; 
     classDef legendTitle fill:none,stroke:none,color:#1F2937,font-weight:bold; 
     classDef legendItem fill:none,stroke:none,color:#4B5563; 
 
     subgraph Legend["图例"] 
         direction LR 
         L1["■ BDCN 模块"]:::legendTitle 
         L2["■ InkLayer 模块"]:::legendTitle 
         L3["■ SketchRefiner 模块"]:::legendTitle 
         L4["■ 用户输入"]:::legendTitle 
         L5["■ 数据流（虚线）"]:::legendTitle 
     end 
 
     class L1,L2,L3,L4,L5 legend;