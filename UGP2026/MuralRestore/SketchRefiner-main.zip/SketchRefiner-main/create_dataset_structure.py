import os

# 创建数据集目录结构
project_dir = 'f:\\桌面\\作业\\壁画数字化图像修复方法及实现\\SketchRefiner-main'
dataset_root = os.path.join(project_dir, 'datasets')
dataset_name = 'dunhuang'
dataset_dir = os.path.join(dataset_root, dataset_name)

# 创建必要的目录
os.makedirs(dataset_dir, exist_ok=True)
os.makedirs(os.path.join(dataset_dir, 'images'), exist_ok=True)
os.makedirs(os.path.join(dataset_dir, 'edges'), exist_ok=True)
os.makedirs(os.path.join(dataset_dir, 'sketches'), exist_ok=True)

# 创建输出目录
output_dir = os.path.join(project_dir, 'output', 'SRN')
os.makedirs(output_dir, exist_ok=True)

print("目录结构创建完成！")
print(f"数据集目录: {dataset_dir}")
print(f"输出目录: {output_dir}")