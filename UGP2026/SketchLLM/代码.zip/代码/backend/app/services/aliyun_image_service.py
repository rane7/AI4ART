import os
import base64
import requests
from dotenv import load_dotenv
from typing import Optional, Dict

load_dotenv()


class AliyunImageService:
    def __init__(self):
        self.api_key = os.environ.get('ALIYUN_API_KEY', '')
        self.api_base = os.environ.get('ALIYUN_API_BASE', 'https://dashscope.aliyuncs.com/api/v1')
        self.model = os.environ.get('ALIYUN_IMAGE_MODEL', 'qwen-image-2.0')
    
    def generate_image(self, prompt: str, size: str = '1024*1024') -> Optional[Dict]:
        """
        调用阿里云通义万相 qwen-image-2.0 生成图像
        
        Args:
            prompt: 图像生成提示词
            size: 图像尺寸
            
        Returns:
            包含 base64 图像数据的字典
        """
        if not self.api_key:
            print("[DEBUG] No API key, using mock")
            return self._mock_generate(prompt)
        
        try:
            url = f"{self.api_base}/services/aigc/multimodal-generation/generation"
            
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                "model": self.model,
                "input": {
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {
                                    "text": prompt
                                }
                            ]
                        }
                    ]
                },
                "parameters": {
                    "size": size,
                    "n": 1,
                    "watermark": False,
                    "prompt_extend": True,
                    "negative_prompt": "低分辨率，低画质，肢体畸形，手指畸形，画面过饱和，蜡像感，人脸无细节，过度光滑，画面具有AI感。构图混乱。文字模糊，扭曲。"
                }
            }
            
            print(f"[DEBUG] Calling API: {url}")
            print(f"[DEBUG] Model: {self.model}")
            print(f"[DEBUG] Prompt: {prompt}")
            
            response = requests.post(url, headers=headers, json=payload, timeout=120)
            
            print(f"[DEBUG] Response status: {response.status_code}")
            print(f"[DEBUG] Response: {response.text[:500] if len(response.text) > 500 else response.text}")
            
            if response.status_code == 200:
                result = response.json()
                
                choices = result.get('output', {}).get('choices', [])
                if choices and len(choices) > 0:
                    content = choices[0].get('message', {}).get('content', [])
                    if content and len(content) > 0:
                        image_url = content[0].get('image', '')
                        if image_url:
                            print(f"[DEBUG] Got image URL: {image_url[:100]}...")
                            image_base64 = self._download_image_as_base64(image_url)
                            if image_base64:
                                return {
                                    'success': True,
                                    'image_base64': image_base64,
                                    'image_url': image_url
                                }
                            else:
                                return {
                                    'success': False,
                                    'error': 'Failed to download image'
                                }
                
                return {
                    'success': False,
                    'error': 'No image in response'
                }
            else:
                return {
                    'success': False,
                    'error': f'API Error: {response.status_code} - {response.text}'
                }
                
        except Exception as e:
            print(f"[ERROR] Exception: {str(e)}")
            import traceback
            traceback.print_exc()
            return {
                'success': False,
                'error': str(e)
            }
    
    def _download_image_as_base64(self, url: str) -> str:
        """
        下载图片并转换为 base64
        
        Args:
            url: 图片URL
            
        Returns:
            base64 编码的图片数据
        """
        try:
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                return base64.b64encode(response.content).decode('utf-8')
            else:
                print(f"[ERROR] Failed to download image: {response.status_code}")
        except Exception as e:
            print(f"[ERROR] Exception downloading image: {str(e)}")
        return ''
    
    def generate_sketch_prompt(self, user_description: str, details: Dict) -> str:
        """
        根据用户描述和收集的细节生成专业的草图提示词
        
        Args:
            user_description: 用户初始描述
            details: 三轮对话收集到的细节信息
            
        Returns:
            专业的英文提示词
        """
        subject = details.get('subject', user_description)
        style = details.get('style', 'simple sketch')
        more_details = details.get('details', '')
        
        prompt_parts = [
            f"A professional sketch drawing of {subject}",
            f"{style} style",
            "clean lines, minimalist design",
            "black and white line art",
            "high quality sketch"
        ]
        
        if more_details:
            prompt_parts.append(f"Additional details: {more_details}")
        
        return ', '.join(prompt_parts)
    
    def _mock_generate(self, prompt: str) -> Dict:
        """
        模拟生成（当没有 API Key 时使用）
        """
        return {
            'success': True,
            'image_base64': '',
            'prompt': prompt,
            'mock': True
        }
