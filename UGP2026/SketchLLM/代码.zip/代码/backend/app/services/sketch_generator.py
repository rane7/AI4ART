import svgwrite
import random
import math
import os
from typing import List, Dict, Optional

DIFFVG_AVAILABLE = False
try:
    import pydiffvg
    import torch
    DIFFVG_AVAILABLE = True
except ImportError:
    pass

class SketchGenerator:
    def __init__(self, canvas_size: int = 224, use_diffvg: bool = True):
        self.canvas_size = canvas_size
        self.stroke_width = 2.5
        self.use_diffvg = use_diffvg and DIFFVG_AVAILABLE
        self.jitter_amount = 0.8
        self.stroke_variation = 1.5
        self.overlap_lines = 3
        
        if self.use_diffvg:
            pydiffvg.set_use_gpu(False)
            print("diffvg enabled - using high-quality vector rendering")
    
    def _jitter_point(self, x: float, y: float, amount: float = None) -> tuple:
        if amount is None:
            amount = self.jitter_amount
        return (
            x + random.uniform(-amount, amount),
            y + random.uniform(-amount, amount)
        )
    
    def _vary_stroke_width(self, base_width: float = None) -> float:
        if base_width is None:
            base_width = self.stroke_width
        return base_width + random.uniform(-self.stroke_variation, self.stroke_variation)
    
    def generate(self, intent: dict) -> str:
        action = intent.get('action', 'generate')
        objects = intent.get('objects', [])
        
        if self.use_diffvg:
            return self._generate_with_diffvg(intent)
        else:
            return self._generate_with_svgwrite(intent)
    
    def _generate_with_svgwrite(self, intent: dict) -> str:
        action = intent.get('action', 'generate')
        objects = intent.get('objects', [])
        
        dwg = svgwrite.Drawing(size=(self.canvas_size, self.canvas_size))
        dwg.add(dwg.rect(insert=(0, 0), size=('100%', '100%'), fill='white'))
        
        if action == 'generate':
            for obj in objects:
                self._draw_object(dwg, obj)
        elif action == 'add':
            for obj in objects:
                self._draw_object(dwg, obj)
        
        return dwg.tostring()
    
    def _generate_with_diffvg(self, intent: dict) -> str:
        action = intent.get('action', 'generate')
        objects = intent.get('objects', [])
        
        shapes = []
        shape_groups = []
        
        for obj in objects:
            obj_shapes, obj_groups = self._create_diffvg_shapes(obj)
            shapes.extend(obj_shapes)
            shape_groups.extend(obj_groups)
        
        if not shapes:
            return self._generate_with_svgwrite(intent)
        
        scene_args = pydiffvg.RenderFunction.serialize_scene(
            self.canvas_size, self.canvas_size, shapes, shape_groups
        )
        
        render = pydiffvg.RenderFunction.apply
        img = render(self.canvas_size, self.canvas_size, 2, 2, 0, None, *scene_args)
        
        img = img[:, :, 3:4] * img[:, :, :3] + torch.ones(img.shape[0], img.shape[1], 3, device=img.device) * (1 - img[:, :, 3:4])
        img = img[:, :, :3]
        
        return self._tensor_to_svg(img, shapes, shape_groups)
    
    def _create_diffvg_shapes(self, obj: dict):
        obj_type = obj.get('type', 'object')
        attributes = obj.get('attributes', {})
        
        cx = attributes.get('position_x', self.canvas_size // 2)
        cy = attributes.get('position_y', self.canvas_size // 2)
        scale = attributes.get('scale', 1.0)
        
        shapes = []
        shape_groups = []
        
        strokes = self._get_object_strokes(obj_type, cx, cy, scale)
        
        for i, stroke in enumerate(strokes):
            if len(stroke) < 2:
                continue
            
            points = torch.tensor(stroke, dtype=torch.float32)
            path = pydiffvg.Path(num_control_points=torch.zeros(len(stroke) - 1, dtype=torch.long),
                                points=points,
                                stroke_width=torch.tensor(self.stroke_width),
                                is_closed=False)
            shapes.append(path)
            
            color = torch.tensor([0.0, 0.0, 0.0, 1.0])
            shape_groups.append(pydiffvg.ShapeGroup(
                shape_ids=torch.tensor([len(shapes) - 1]),
                fill_color=None,
                stroke_color=color
            ))
        
        return shapes, shape_groups
    
    def _tensor_to_svg(self, img, shapes, shape_groups) -> str:
        dwg = svgwrite.Drawing(size=(self.canvas_size, self.canvas_size))
        dwg.add(dwg.rect(insert=(0, 0), size=('100%', '100%'), fill='white'))
        
        for shape, group in zip(shapes, shape_groups):
            if isinstance(shape, pydiffvg.Path):
                points = shape.points.detach().cpu().numpy()
                path_data = f"M {points[0][0]:.1f} {points[0][1]:.1f}"
                for p in points[1:]:
                    path_data += f" L {p[0]:.1f} {p[1]:.1f}"
                
                stroke_color = 'black'
                if group.stroke_color is not None:
                    color = group.stroke_color.detach().cpu().numpy()
                    if len(color) >= 3:
                        stroke_color = f'rgb({int(color[0]*255)},{int(color[1]*255)},{int(color[2]*255)})'
                
                dwg.add(dwg.path(d=path_data, stroke=stroke_color, fill='none',
                               stroke_width=float(shape.stroke_width)))
        
        return dwg.tostring()
    
    def modify(self, svg_content: str, modifications: list) -> str:
        dwg = svgwrite.Drawing(size=(self.canvas_size, self.canvas_size))
        dwg.add(dwg.rect(insert=(0, 0), size=('100%', '100%'), fill='white'))
        
        for mod in modifications:
            self._apply_modification(dwg, mod)
        
        return dwg.tostring()
    
    def _draw_object(self, dwg: svgwrite.Drawing, obj: dict):
        obj_type = obj.get('type', 'object')
        attributes = obj.get('attributes', {})
        
        center_x = attributes.get('position_x', self.canvas_size // 2)
        center_y = attributes.get('position_y', self.canvas_size // 2)
        scale = attributes.get('scale', 1.0)
        
        strokes = self._get_object_strokes(obj_type, center_x, center_y, scale)
        
        for stroke in strokes:
            for _ in range(self.overlap_lines):
                jittered_stroke = [self._jitter_point(p[0], p[1]) for p in stroke]
                path_data = self._stroke_to_path(jittered_stroke)
                varied_width = self._vary_stroke_width()
                dwg.add(dwg.path(d=path_data, stroke='black', fill='none', 
                               stroke_width=varied_width,
                               stroke_linecap='round',
                               stroke_linejoin='round'))
    
    def _get_object_strokes(self, obj_type: str, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        strokes = []
        
        if obj_type == 'car':
            strokes = self._draw_car(cx, cy, scale)
        elif obj_type == 'house':
            strokes = self._draw_house(cx, cy, scale)
        elif obj_type == 'person':
            strokes = self._draw_person(cx, cy, scale)
        elif obj_type == 'tree':
            strokes = self._draw_tree(cx, cy, scale)
        elif obj_type == 'cat':
            strokes = self._draw_cat(cx, cy, scale)
        elif obj_type == 'sun':
            strokes = self._draw_sun(cx, cy, scale)
        elif obj_type == 'dog':
            strokes = self._draw_dog(cx, cy, scale)
        elif obj_type == 'bird':
            strokes = self._draw_bird(cx, cy, scale)
        elif obj_type == 'flower':
            strokes = self._draw_flower(cx, cy, scale)
        elif obj_type == 'mountain':
            strokes = self._draw_mountain(cx, cy, scale)
        else:
            strokes = self._draw_generic(cx, cy, scale)
        
        return strokes
    
    def _draw_car(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 28
        strokes = []
        
        body_top = [
            (cx - 2.0*s, cy),
            (cx - 1.6*s, cy - 0.9*s),
            (cx - 1.2*s, cy - 1.1*s),
            (cx + 0.8*s, cy - 1.1*s),
            (cx + 1.6*s, cy - 0.8*s),
            (cx + 2.2*s, cy),
        ]
        strokes.append(body_top)
        
        body_bottom = [
            (cx - 2.8*s, cy),
            (cx + 2.8*s, cy),
        ]
        strokes.append(body_bottom)
        
        window_front = [
            (cx - 1.4*s, cy - 0.95*s),
            (cx - 0.4*s, cy - 1.05*s),
            (cx - 0.3*s, cy - 0.5*s),
            (cx - 1.5*s, cy - 0.4*s),
        ]
        strokes.append(window_front)
        
        window_back = [
            (cx + 0.4*s, cy - 1.05*s),
            (cx + 1.4*s, cy - 0.85*s),
            (cx + 1.5*s, cy - 0.4*s),
            (cx + 0.3*s, cy - 0.5*s),
        ]
        strokes.append(window_back)
        
        window_divider = [
            (cx - 0.3*s, cy - 0.5*s),
            (cx + 0.3*s, cy - 0.5*s),
        ]
        strokes.append(window_divider)
        
        wheel_r = 0.5 * s
        wheel1_cx, wheel1_cy = cx - 1.8*s, cy + 0.3*s
        strokes.append(self._draw_circle_soft(wheel1_cx, wheel1_cy, wheel_r))
        strokes.append(self._draw_circle_soft(wheel1_cx, wheel1_cy, wheel_r * 0.6))
        
        wheel2_cx, wheel2_cy = cx + 1.8*s, cy + 0.3*s
        strokes.append(self._draw_circle_soft(wheel2_cx, wheel2_cy, wheel_r))
        strokes.append(self._draw_circle_soft(wheel2_cx, wheel2_cy, wheel_r * 0.6))
        
        front_light = [
            (cx + 2.6*s, cy - 0.15*s),
            (cx + 2.8*s, cy - 0.05*s),
            (cx + 2.8*s, cy + 0.05*s),
            (cx + 2.6*s, cy + 0.15*s),
        ]
        strokes.append(front_light)
        
        ground_line = [
            (cx - 3.0*s, cy + wheel_r + 0.35*s),
            (cx + 3.0*s, cy + wheel_r + 0.35*s),
        ]
        strokes.append(ground_line)
        
        return strokes
    
    def _draw_circle_soft(self, cx: float, cy: float, r: float, segments: int = 24) -> List[tuple]:
        points = []
        for i in range(segments):
            angle = 2 * math.pi * i / segments
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            points.append(self._jitter_point(x, y, 0.3))
        points.append(points[0])
        return points
    
    def _draw_house(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 25
        strokes = []
        
        wall = [
            (cx - 2.2*s, cy + 1.2*s),
            (cx - 2.2*s, cy - 0.8*s),
            (cx + 2.2*s, cy - 0.8*s),
            (cx + 2.2*s, cy + 1.2*s),
        ]
        strokes.append(wall)
        
        roof = [
            (cx - 2.8*s, cy - 0.8*s),
            (cx, cy - 2.3*s),
            (cx + 2.8*s, cy - 0.8*s),
        ]
        strokes.append(roof)
        
        roof_edge = [
            (cx - 2.8*s, cy - 0.8*s),
            (cx - 2.4*s, cy - 0.95*s),
            (cx, cy - 2.1*s),
            (cx + 2.4*s, cy - 0.95*s),
            (cx + 2.8*s, cy - 0.8*s),
        ]
        strokes.append(roof_edge)
        
        door = [
            (cx - 0.6*s, cy + 1.2*s),
            (cx - 0.6*s, cy),
            (cx + 0.6*s, cy),
            (cx + 0.6*s, cy + 1.2*s),
        ]
        strokes.append(door)
        
        door_knob = [
            (cx + 0.3*s, cy + 0.6*s),
        ]
        strokes.append(self._draw_circle_soft(cx + 0.3*s, cy + 0.6*s, 0.08*s))
        
        window_left = [
            (cx - 1.8*s, cy - 0.3*s),
            (cx - 1.8*s, cy + 0.5*s),
            (cx - 1.0*s, cy + 0.5*s),
            (cx - 1.0*s, cy - 0.3*s),
        ]
        strokes.append(window_left)
        strokes.append([(cx - 1.4*s, cy - 0.3*s), (cx - 1.4*s, cy + 0.5*s)])
        strokes.append([(cx - 1.8*s, cy + 0.1*s), (cx - 1.0*s, cy + 0.1*s)])
        
        window_right = [
            (cx + 1.0*s, cy - 0.3*s),
            (cx + 1.0*s, cy + 0.5*s),
            (cx + 1.8*s, cy + 0.5*s),
            (cx + 1.8*s, cy - 0.3*s),
        ]
        strokes.append(window_right)
        strokes.append([(cx + 1.4*s, cy - 0.3*s), (cx + 1.4*s, cy + 0.5*s)])
        strokes.append([(cx + 1.0*s, cy + 0.1*s), (cx + 1.8*s, cy + 0.1*s)])
        
        return strokes
    
    def _draw_person(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 20
        strokes = []
        
        strokes.append(self._draw_circle_soft(cx, cy - 2.2*s, 0.7*s))
        
        eye_left = self._draw_circle_soft(cx - 0.25*s, cy - 2.3*s, 0.08*s)
        strokes.append(eye_left)
        eye_right = self._draw_circle_soft(cx + 0.25*s, cy - 2.3*s, 0.08*s)
        strokes.append(eye_right)
        
        mouth = [
            (cx - 0.2*s, cy - 1.9*s),
            (cx, cy - 1.75*s),
            (cx + 0.2*s, cy - 1.9*s),
        ]
        strokes.append(mouth)
        
        body = [
            (cx, cy - 1.5*s),
            (cx, cy + 0.8*s),
        ]
        strokes.append(body)
        
        arm_left = [
            (cx - 1.2*s, cy - 0.3*s),
            (cx - 0.2*s, cy - 0.1*s),
            (cx, cy - 0.6*s),
        ]
        strokes.append(arm_left)
        
        arm_right = [
            (cx, cy - 0.6*s),
            (cx + 0.2*s, cy - 0.1*s),
            (cx + 1.2*s, cy - 0.3*s),
        ]
        strokes.append(arm_right)
        
        leg_left = [
            (cx, cy + 0.8*s),
            (cx - 0.9*s, cy + 2.5*s),
        ]
        strokes.append(leg_left)
        
        leg_right = [
            (cx, cy + 0.8*s),
            (cx + 0.9*s, cy + 2.5*s),
        ]
        strokes.append(leg_right)
        
        return strokes
    
    def _draw_tree(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 18
        strokes = []
        
        trunk = [
            (cx - 0.4*s, cy + 2.5*s),
            (cx - 0.35*s, cy - 0.3*s),
            (cx + 0.35*s, cy - 0.3*s),
            (cx + 0.4*s, cy + 2.5*s),
        ]
        strokes.append(trunk)
        
        for i in range(3):
            r = (1.8 - i*0.4) * s
            y_offset = cy - 0.5*s - i * 1.0 * s
            strokes.append(self._draw_circle_soft(cx, y_offset, r))
        
        return strokes
    
    def _draw_cat(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 18
        strokes = []
        
        strokes.append(self._draw_circle_soft(cx, cy, 1.4*s))
        
        ear_left = [
            (cx - 1.2*s, cy - 1.0*s),
            (cx - 0.8*s, cy - 2.0*s),
            (cx - 0.4*s, cy - 1.0*s),
        ]
        strokes.append(ear_left)
        
        ear_right = [
            (cx + 1.2*s, cy - 1.0*s),
            (cx + 0.8*s, cy - 2.0*s),
            (cx + 0.4*s, cy - 1.0*s),
        ]
        strokes.append(ear_right)
        
        eye_left = self._draw_circle_soft(cx - 0.5*s, cy - 0.2*s, 0.15*s)
        strokes.append(eye_left)
        eye_right = self._draw_circle_soft(cx + 0.5*s, cy - 0.2*s, 0.15*s)
        strokes.append(eye_right)
        
        nose = [
            (cx, cy + 0.3*s),
            (cx - 0.15*s, cy + 0.5*s),
            (cx + 0.15*s, cy + 0.5*s),
        ]
        strokes.append(nose)
        
        mouth_left = [
            (cx - 0.15*s, cy + 0.5*s),
            (cx - 0.4*s, cy + 0.8*s),
        ]
        strokes.append(mouth_left)
        mouth_right = [
            (cx + 0.15*s, cy + 0.5*s),
            (cx + 0.4*s, cy + 0.8*s),
        ]
        strokes.append(mouth_right)
        
        whisker_left_1 = [(cx - 0.8*s, cy + 0.4*s), (cx - 1.8*s, cy + 0.2*s)]
        whisker_left_2 = [(cx - 0.8*s, cy + 0.6*s), (cx - 1.8*s, cy + 0.6*s)]
        whisker_left_3 = [(cx - 0.8*s, cy + 0.8*s), (cx - 1.8*s, cy + 1.0*s)]
        strokes.extend([whisker_left_1, whisker_left_2, whisker_left_3])
        
        whisker_right_1 = [(cx + 0.8*s, cy + 0.4*s), (cx + 1.8*s, cy + 0.2*s)]
        whisker_right_2 = [(cx + 0.8*s, cy + 0.6*s), (cx + 1.8*s, cy + 0.6*s)]
        whisker_right_3 = [(cx + 0.8*s, cy + 0.8*s), (cx + 1.8*s, cy + 1.0*s)]
        strokes.extend([whisker_right_1, whisker_right_2, whisker_right_3])
        
        body = [
            (cx - 0.5*s, cy + 1.2*s),
            (cx - 1.2*s, cy + 2.5*s),
            (cx + 1.2*s, cy + 2.5*s),
            (cx + 0.5*s, cy + 1.2*s),
        ]
        strokes.append(body)
        
        tail = [
            (cx + 1.4*s, cy + 1.8*s),
            (cx + 2.2*s, cy + 1.2*s),
            (cx + 2.8*s, cy + 1.8*s),
            (cx + 3.0*s, cy + 1.0*s),
        ]
        strokes.append(tail)
        
        return strokes
    
    def _draw_dog(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 18
        strokes = []
        
        strokes.append(self._draw_circle_soft(cx, cy, 1.4*s))
        
        ear_left = [
            (cx - 1.0*s, cy - 1.4*s),
            (cx - 1.5*s, cy - 0.8*s),
            (cx - 0.6*s, cy - 0.8*s),
        ]
        strokes.append(ear_left)
        
        ear_right = [
            (cx + 1.0*s, cy - 1.4*s),
            (cx + 1.5*s, cy - 0.8*s),
            (cx + 0.6*s, cy - 0.8*s),
        ]
        strokes.append(ear_right)
        
        eye_left = self._draw_circle_soft(cx - 0.5*s, cy - 0.2*s, 0.15*s)
        strokes.append(eye_left)
        eye_right = self._draw_circle_soft(cx + 0.5*s, cy - 0.2*s, 0.15*s)
        strokes.append(eye_right)
        
        nose = self._draw_circle_soft(cx, cy + 0.6*s, 0.2*s)
        strokes.append(nose)
        
        mouth = [
            (cx - 0.4*s, cy + 1.0*s),
            (cx, cy + 1.4*s),
            (cx + 0.4*s, cy + 1.0*s),
        ]
        strokes.append(mouth)
        
        body = [
            (cx - 0.6*s, cy + 1.4*s),
            (cx - 1.5*s, cy + 2.8*s),
            (cx + 1.5*s, cy + 2.8*s),
            (cx + 0.6*s, cy + 1.4*s),
        ]
        strokes.append(body)
        
        leg1 = [(cx - 1.2*s, cy + 2.8*s), (cx - 1.2*s, cy + 4.0*s)]
        leg2 = [(cx - 0.3*s, cy + 2.8*s), (cx - 0.3*s, cy + 4.0*s)]
        leg3 = [(cx + 0.3*s, cy + 2.8*s), (cx + 0.3*s, cy + 4.0*s)]
        leg4 = [(cx + 1.2*s, cy + 2.8*s), (cx + 1.2*s, cy + 4.0*s)]
        strokes.extend([leg1, leg2, leg3, leg4])
        
        tail = [
            (cx + 1.6*s, cy + 2.0*s),
            (cx + 2.5*s, cy + 1.5*s),
            (cx + 3.0*s, cy + 2.2*s),
        ]
        strokes.append(tail)
        
        return strokes
    
    def _draw_bird(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 14
        strokes = []
        
        strokes.append(self._draw_circle_soft(cx - 0.6*s, cy, 1.0*s))
        
        eye = self._draw_circle_soft(cx - 0.8*s, cy - 0.1*s, 0.12*s)
        strokes.append(eye)
        
        beak = [
            (cx - 1.4*s, cy),
            (cx - 2.2*s, cy - 0.2*s),
            (cx - 2.2*s, cy + 0.2*s),
            (cx - 1.4*s, cy),
        ]
        strokes.append(beak)
        
        body = [
            (cx - 0.2*s, cy - 0.2*s),
            (cx + 0.8*s, cy - 1.0*s),
            (cx + 2.0*s, cy - 0.5*s),
            (cx + 1.8*s, cy + 0.5*s),
            (cx + 0.8*s, cy + 1.0*s),
            (cx - 0.2*s, cy + 0.2*s),
        ]
        strokes.append(body)
        
        wing = [
            (cx, cy - 0.1*s),
            (cx + 0.6*s, cy - 1.2*s),
            (cx + 1.8*s, cy - 0.6*s),
            (cx + 1.2*s, cy),
        ]
        strokes.append(wing)
        
        tail = [
            (cx + 1.6*s, cy - 0.3*s),
            (cx + 2.8*s, cy - 0.8*s),
            (cx + 2.8*s, cy + 0.2*s),
            (cx + 1.6*s, cy + 0.3*s),
        ]
        strokes.append(tail)
        
        leg1 = [(cx + 0.2*s, cy + 1.0*s), (cx + 0.2*s, cy + 2.0*s)]
        leg2 = [(cx + 0.8*s, cy + 1.0*s), (cx + 0.8*s, cy + 2.0*s)]
        strokes.extend([leg1, leg2])
        
        return strokes
    
    def _draw_flower(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 14
        strokes = []
        
        strokes.append(self._draw_circle_soft(cx, cy, 0.6*s))
        
        for i in range(6):
            angle = i * 2 * math.pi / 6
            px = cx + 1.1*s * math.cos(angle)
            py = cy + 1.1*s * math.sin(angle)
            strokes.append(self._draw_circle_soft(px, py, 0.7*s))
        
        stem = [
            (cx, cy + 0.6*s),
            (cx - 0.2*s, cy + 1.8*s),
            (cx, cy + 3.0*s),
        ]
        strokes.append(stem)
        
        leaf1 = [
            (cx - 0.2*s, cy + 1.8*s),
            (cx - 1.5*s, cy + 1.2*s),
            (cx - 1.8*s, cy + 1.8*s),
            (cx - 0.8*s, cy + 2.2*s),
        ]
        strokes.append(leaf1)
        
        leaf2 = [
            (cx, cy + 2.4*s),
            (cx + 1.2*s, cy + 1.8*s),
            (cx + 1.6*s, cy + 2.4*s),
            (cx + 0.6*s, cy + 2.8*s),
        ]
        strokes.append(leaf2)
        
        return strokes
    
    def _draw_mountain(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 22
        strokes = []
        
        main_mountain = [
            (cx - 2.5*s, cy + 1.8*s),
            (cx - 1.0*s, cy - 0.2*s),
            (cx, cy - 1.8*s),
            (cx + 1.0*s, cy - 0.2*s),
            (cx + 2.5*s, cy + 1.8*s),
        ]
        strokes.append(main_mountain)
        
        snow_cap = [
            (cx - 0.8*s, cy - 0.4*s),
            (cx - 0.3*s, cy - 1.0*s),
            (cx, cy - 1.8*s),
            (cx + 0.3*s, cy - 1.0*s),
            (cx + 0.8*s, cy - 0.4*s),
        ]
        strokes.append(snow_cap)
        
        left_mountain = [
            (cx - 3.5*s, cy + 1.8*s),
            (cx - 2.2*s, cy + 0.2*s),
            (cx - 1.2*s, cy + 1.2*s),
        ]
        strokes.append(left_mountain)
        
        right_mountain = [
            (cx + 1.2*s, cy + 1.2*s),
            (cx + 2.2*s, cy + 0.2*s),
            (cx + 3.5*s, cy + 1.8*s),
        ]
        strokes.append(right_mountain)
        
        return strokes
    
    def _draw_sun(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 14
        strokes = []
        
        strokes.append(self._draw_circle_soft(cx, cy, 1.2*s))
        
        face_eye_left = self._draw_circle_soft(cx - 0.4*s, cy - 0.15*s, 0.12*s)
        strokes.append(face_eye_left)
        face_eye_right = self._draw_circle_soft(cx + 0.4*s, cy - 0.15*s, 0.12*s)
        strokes.append(face_eye_right)
        
        face_smile = [
            (cx - 0.5*s, cy + 0.2*s),
            (cx - 0.25*s, cy + 0.5*s),
            (cx, cy + 0.6*s),
            (cx + 0.25*s, cy + 0.5*s),
            (cx + 0.5*s, cy + 0.2*s),
        ]
        strokes.append(face_smile)
        
        for i in range(12):
            angle = i * math.pi / 6
            x1 = cx + 1.5*s * math.cos(angle)
            y1 = cy + 1.5*s * math.sin(angle)
            x2 = cx + 2.3*s * math.cos(angle)
            y2 = cy + 2.3*s * math.sin(angle)
            strokes.append([(x1, y1), (x2, y2)])
        
        return strokes
    
    def _draw_generic(self, cx: int, cy: int, scale: float) -> List[List[tuple]]:
        s = scale * 22
        strokes = []
        
        main_shape = []
        num_points = random.randint(6, 10)
        for i in range(num_points):
            angle = 2 * math.pi * i / num_points
            r = s * (0.6 + random.uniform(-0.2, 0.4))
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            main_shape.append((x, y))
        main_shape.append(main_shape[0])
        strokes.append(main_shape)
        
        for _ in range(random.randint(2, 4)):
            detail = []
            start_angle = random.uniform(0, 2 * math.pi)
            start_r = s * 0.3
            x = cx + start_r * math.cos(start_angle)
            y = cy + start_r * math.sin(start_angle)
            detail.append((x, y))
            
            for _ in range(random.randint(2, 5)):
                angle = random.uniform(0, 2 * math.pi)
                r = random.uniform(s * 0.2, s * 0.8)
                x = cx + r * math.cos(angle)
                y = cy + r * math.sin(angle)
                detail.append((x, y))
            
            strokes.append(detail)
        
        return strokes
    
    def _draw_circle(self, cx: int, cy: int, r: float) -> List[tuple]:
        points = []
        for i in range(16):
            angle = 2 * math.pi * i / 16
            x = cx + r * math.cos(angle)
            y = cy + r * math.sin(angle)
            points.append((x, y))
        points.append(points[0])
        return points
    
    def _stroke_to_path(self, stroke: List[tuple]) -> str:
        if not stroke:
            return ""
        
        path = f"M {stroke[0][0]:.1f} {stroke[0][1]:.1f}"
        
        for point in stroke[1:]:
            path += f" L {point[0]:.1f} {point[1]:.1f}"
        
        return path
    
    def _apply_modification(self, dwg: svgwrite.Drawing, mod: dict):
        operation = mod.get('operation', 'adjust')
        target = mod.get('target', '')
        description = mod.get('description', '')
        
        if '变大' in description or '放大' in description:
            self._draw_object(dwg, {'type': target, 'attributes': {'scale': 1.3}})
        elif '变小' in description or '缩小' in description:
            self._draw_object(dwg, {'type': target, 'attributes': {'scale': 0.7}})
        else:
            self._draw_object(dwg, {'type': target, 'attributes': {}})
