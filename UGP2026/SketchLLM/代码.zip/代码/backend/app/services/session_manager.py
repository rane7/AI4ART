import os
import json
import uuid
from datetime import datetime
from typing import Optional, Dict, List

class Session:
    def __init__(self, session_id: str = None):
        self.id = session_id or str(uuid.uuid4())
        self.created_at = datetime.now().isoformat()
        self.messages: List[Dict] = []
        self.sketch_history: List[str] = []
        self.current_sketch: Optional[str] = None
        self.state: Dict = {
            'current_stage': 0,
            'collected_details': {},
            'generation_method': 'clipascene',
            'initial_description': ''
        }
    
    def add_message(self, role: str, content: str, image: str = None):
        msg = {
            'role': role,
            'content': content,
            'timestamp': datetime.now().isoformat()
        }
        if image:
            msg['image'] = image
        self.messages.append(msg)
    
    def get_history(self) -> List[Dict]:
        return self.messages
    
    def update_sketch(self, svg_content: str):
        self.current_sketch = svg_content
        self.sketch_history.append({
            'svg': svg_content,
            'timestamp': datetime.now().isoformat()
        })
    
    def get_current_sketch(self) -> Optional[str]:
        return self.current_sketch
    
    def get_sketch_history(self) -> List[Dict]:
        return self.sketch_history
    
    def set_generation_method(self, method: str):
        self.state['generation_method'] = method
    
    def get_generation_method(self) -> str:
        return self.state.get('generation_method', 'clipascene')
    
    def reset_intent_state(self):
        self.state['current_stage'] = 0
        self.state['collected_details'] = {}
        self.state['initial_description'] = ''
    
    def update_intent_state(self, state_updates: Dict):
        self.state.update(state_updates)
    
    def get_intent_state(self) -> Dict:
        return self.state
    
    def to_dict(self) -> Dict:
        return {
            'id': self.id,
            'created_at': self.created_at,
            'messages': self.messages,
            'sketch_history': self.sketch_history,
            'current_sketch': self.current_sketch,
            'state': self.state
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Session':
        session = cls(data['id'])
        session.created_at = data.get('created_at', '')
        session.messages = data.get('messages', [])
        session.sketch_history = data.get('sketch_history', [])
        session.current_sketch = data.get('current_sketch')
        session.state = data.get('state', {})
        return session


class SessionManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SessionManager, cls).__new__(cls)
            cls._instance.sessions = {}
            cls._instance.app = None
        return cls._instance
    
    def init_app(self, app):
        self.app = app
    
    def create(self) -> Session:
        session = Session()
        self.sessions[session.id] = session
        return session
    
    def get(self, session_id: str) -> Optional[Session]:
        return self.sessions.get(session_id)
    
    def get_or_create(self, session_id: str = None) -> Session:
        if session_id and session_id in self.sessions:
            return self.sessions[session_id]
        return self.create()
    
    def delete(self, session_id: str) -> bool:
        if session_id in self.sessions:
            del self.sessions[session_id]
            return True
        return False
    
    def save_session(self, session: Session, folder: str):
        file_path = os.path.join(folder, f'{session.id}.json')
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(session.to_dict(), f, ensure_ascii=False, indent=2)
    
    def load_session(self, session_id: str, folder: str) -> Optional[Session]:
        file_path = os.path.join(folder, f'{session_id}.json')
        if not os.path.exists(file_path):
            return None
        
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        session = Session.from_dict(data)
        self.sessions[session.id] = session
        return session


session_manager = SessionManager()
