import os
import json
import base64
from dotenv import load_dotenv
from zhipuai import ZhipuAI
from backend.app.utils.prompt_templates import INTENT_PARSE_PROMPT

load_dotenv()

class LLMService:
    def __init__(self):
        api_key = os.environ.get('ZHIPU_API_KEY', '')
        self.model = os.environ.get('ZHIPU_MODEL', 'glm-4.6v')
        self.client = ZhipuAI(api_key=api_key) if api_key else None
    
    def parse_intent(self, user_message: str, history: list = None, image_base64: str = None) -> dict:
        if not self.client:
            return self._mock_parse(user_message)
        
        prompt = INTENT_PARSE_PROMPT.format(
            history=self._format_history(history or []),
            user_message=user_message
        )
        
        messages = [
            {"role": "system", "content": "你是一个草图生成系统的意图解析助手。请将用户的自然语言输入或图片内容解析为结构化的指令。如果用户上传了图片，请分析图片内容并生成对应的草图描述。"}
        ]
        
        if image_base64:
            user_content = [
                {"type": "text", "text": f"用户上传了一张图片，请分析图片内容。\n\n{prompt}"}
            ]
            if image_base64.startswith('data:'):
                image_url = image_base64
            else:
                image_url = f"data:image/jpeg;base64,{image_base64}"
            user_content.append({
                "type": "image_url",
                "image_url": {"url": image_url}
            })
            messages.append({"role": "user", "content": user_content})
        else:
            messages.append({"role": "user", "content": prompt})
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.7,
        )
        
        content = response.choices[0].message.content
        return self._parse_response(content, has_image=image_base64 is not None)
    
    def _format_history(self, history: list) -> str:
        if not history:
            return "无历史对话"
        return "\n".join([
            f"{msg['role']}: {msg['content']}" 
            for msg in history[-5:]
        ])
    
    def _parse_response(self, content: str, has_image: bool = False) -> dict:
        try:
            json_start = content.find('{')
            json_end = content.rfind('}') + 1
            if json_start != -1 and json_end > json_start:
                json_str = content[json_start:json_end]
                result = json.loads(json_str)
                if has_image and 'response' not in result:
                    result['response'] = "我已分析了您上传的图片，正在生成对应的草图..."
                return result
        except json.JSONDecodeError:
            pass
        
        return {
            "action": "generate",
            "objects": [],
            "response": content,
            "has_image": has_image
        }
    
    def _mock_parse(self, user_message: str) -> dict:
        if any(word in user_message for word in ['改', '修改', '调整', '变大', '变小', '移动']):
            return {
                "action": "modify",
                "modifications": [{
                    "target": "detected_object",
                    "operation": "adjust",
                    "description": user_message
                }],
                "response": f"我理解您想要修改草图：{user_message}"
            }
        elif any(word in user_message for word in ['添加', '加一个', '增加']):
            return {
                "action": "add",
                "objects": [{
                    "type": "new_object",
                    "description": user_message
                }],
                "response": f"好的，我来为您添加：{user_message}"
            }
        elif any(word in user_message for word in ['删除', '去掉', '移除']):
            return {
                "action": "delete",
                "target": "detected_object",
                "response": f"好的，我来删除该元素"
            }
        else:
            return {
                "action": "generate",
                "objects": [{
                    "type": self._extract_object_type(user_message),
                    "attributes": {
                        "style": "simple",
                        "stroke_count": 16
                    }
                }],
                "response": f"好的，我来为您绘制：{user_message}"
            }
    
    def _extract_object_type(self, message: str) -> str:
        object_keywords = {
            '车': 'car', '汽车': 'car', '轿车': 'car',
            '房子': 'house', '建筑': 'building',
            '人': 'person', '人物': 'person',
            '树': 'tree', '花': 'flower',
            '猫': 'cat', '狗': 'dog', '鸟': 'bird',
            '太阳': 'sun', '月亮': 'moon', '星星': 'star',
            '山': 'mountain', '河': 'river', '海': 'sea'
        }
        for keyword, obj_type in object_keywords.items():
            if keyword in message:
                return obj_type
        return 'object'
