import os
import json
import base64
from dotenv import load_dotenv
from zhipuai import ZhipuAI
from typing import Dict, List, Optional

load_dotenv()


class IntentUnderstandingService:
    def __init__(self):
        api_key = os.environ.get('ZHIPU_API_KEY', '')
        self.model = os.environ.get('ZHIPU_MODEL', 'glm-4.6v')
        self.client = ZhipuAI(api_key=api_key) if api_key else None
    
    def process_message(self, user_message: str, session_state: Dict, image_base64: str = None) -> Dict:
        """
        处理用户消息，进行多轮对话意图理解
        
        Args:
            user_message: 用户输入的消息
            session_state: 会话状态，包含当前阶段、已收集的信息等
            image_base64: 用户上传的图片（可选）
            
        Returns:
            处理结果，包含回复、是否完成、收集到的信息等
        """
        generation_method = session_state.get('generation_method', 'clipascene')
        
        if generation_method == 'clipascene':
            return self._process_clipascene(user_message, session_state, image_base64)
        else:
            return self._process_qwen_image(user_message, session_state, image_base64)
    
    def _process_qwen_image(self, user_message: str, session_state: Dict, image_base64: str = None) -> Dict:
        """处理 qwen-image 方式的两轮对话"""
        if not self.client:
            return self._mock_process(user_message, session_state)
        
        conversation_history = session_state.get('conversation_history', [])
        current_stage = session_state.get('current_stage', 0)
        
        messages = self._build_conversation_messages(
            user_message, 
            conversation_history,
            current_stage,
            image_base64
        )
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.7,
            )
            
            assistant_response = response.choices[0].message.content.strip()
            
            conversation_history.append({"role": "user", "content": user_message})
            conversation_history.append({"role": "assistant", "content": assistant_response})
            
            result = self._parse_llm_response(assistant_response, current_stage)
            result['conversation_history'] = conversation_history
            
            return result
            
        except Exception as e:
            print(f"LLM 调用失败: {e}")
            return {
                'response': f"抱歉，处理您的请求时出现了问题：{str(e)}",
                'completed': False,
                'current_stage': current_stage,
                'generation_method': 'qwen-image'
            }
    
    def _build_conversation_messages(self, user_message: str, history: List, 
                                      current_stage: int,
                                      image_base64: str = None) -> List[Dict]:
        """构建对话消息"""
        
        if current_stage == 0:
            system_prompt = """你是一个专业的草图生成助手。

用户会告诉你想画什么，你需要一次性询问所有需要的细节信息。

## 你需要了解的信息
1. **主体细节**：具体是什么？（颜色、姿态、表情等）
2. **风格**：什么风格？（简笔画、素描、卡通、写实、水墨等）
3. **颜色**：黑白还是彩色？
4. **背景**：纯色背景还是场景背景？
5. **构图**：居中、偏左、偏右等

## 重要规则
1. 在一条消息中列出所有问题，不要分多次询问
2. 问题要简洁明了
3. 如果用户已经提供了某些信息，不要再问
4. 使用友好的语气

## 回复格式示例
"好的，我来帮您画一只猫！请告诉我以下细节：
1. 猫的颜色和姿态是什么？
2. 您希望是什么风格？（简笔画/素描/卡通/写实）
3. 黑白还是彩色？
4. 背景要求是什么？

请一次性回答这些问题，我就可以为您生成草图了！" """
        else:
            system_prompt = """你是一个专业的图像生成提示词专家。

用户已经回答了所有问题，现在请根据用户的需求生成一个专业的英文图像生成提示词。

## 重要规则
1. 只输出提示词本身，不要输出其他内容
2. 使用英文
3. 提示词要包含：主体、风格、颜色、背景、构图等信息
4. 格式：`[READY]提示词内容`

## 示例
用户回答：橘黄色的猫，坐着，简笔画风格，黑白的，简单背景
输出：[READY]A simple black and white sketch of an orange cat sitting, minimalist line art style, clean simple background, centered composition, hand-drawn appearance"""
        
        messages = [{"role": "system", "content": system_prompt}]
        
        for msg in history[-10:]:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        if image_base64:
            user_content = [
                {"type": "text", "text": user_message if user_message else "请看这张图片，帮我理解它并转化为草图"},
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{image_base64}"
                    }
                }
            ]
            messages.append({"role": "user", "content": user_content})
        else:
            messages.append({"role": "user", "content": user_message})
        
        return messages
    
    def _parse_llm_response(self, response: str, current_stage: int) -> Dict:
        """解析 LLM 的回复"""
        
        if '[READY]' in response:
            prompt_start = response.find('[READY]') + len('[READY]')
            final_prompt = response[prompt_start:].strip()
            
            if final_prompt.startswith('"') and final_prompt.endswith('"'):
                final_prompt = final_prompt[1:-1]
            
            clean_response = response.replace('[READY]', '').replace(final_prompt, '').strip()
            if not clean_response:
                clean_response = "太好了！我已经了解了您的需求，正在为您生成草图..."
            
            return {
                'response': clean_response,
                'current_stage': current_stage + 1,
                'completed': True,
                'final_prompt': final_prompt,
                'generation_method': 'qwen-image'
            }
        
        return {
            'response': response,
            'current_stage': current_stage + 1,
            'completed': False,
            'generation_method': 'qwen-image'
        }
    
    def _process_clipascene(self, user_message: str, session_state: Dict, image_base64: str = None) -> Dict:
        """处理 CLIPascene 方式的对话"""
        if not self.client:
            return self._mock_parse(user_message)
        
        messages = self._build_clipascene_messages(user_message, session_state, image_base64)
        
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=0.7,
            )
            
            content = response.choices[0].message.content
            parsed = self._parse_response(content)
            parsed['generation_method'] = 'clipascene'
            parsed['completed'] = True
            
            return parsed
        except Exception as e:
            print(f"CLIPascene 处理失败: {e}")
            return self._mock_parse(user_message)
    
    def _build_clipascene_messages(self, user_message: str, session_state: Dict, image_base64: str = None) -> List[Dict]:
        """构建 CLIPascene 的消息"""
        history = session_state.get('history', [])
        history_str = "\n".join([
            f"{msg['role']}: {msg['content']}" 
            for msg in history[-5:]
        ]) if history else "无历史对话"
        
        system_prompt = f"""你是一个草图生成系统的意图解析器。请分析用户的输入，将其解析为结构化的指令。

## 历史对话
{history_str}

## 输出格式
请以JSON格式输出：
```json
{{
    "action": "generate|modify|add|delete|adjust",
    "objects": [
        {{
            "type": "对象类型",
            "attributes": {{
                "position_x": 112,
                "position_y": 140,
                "scale": 1.0,
                "style": "simple"
            }}
        }}
    ],
    "modifications": [],
    "response": "对用户的回复"
}}
```"""
        
        messages = [{"role": "system", "content": system_prompt}]
        
        if image_base64:
            user_content = [
                {"type": "text", "text": f"用户输入：{user_message}\n\n请分析用户上传的图片和输入，生成结构化指令。"},
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/jpeg;base64,{image_base64}"
                    }
                }
            ]
            messages.append({"role": "user", "content": user_content})
        else:
            messages.append({"role": "user", "content": f"用户输入：{user_message}\n\n请生成结构化指令。"})
        
        return messages
    
    def _parse_response(self, content: str) -> Dict:
        """解析 LLM 返回的响应"""
        try:
            json_start = content.find('{')
            json_end = content.rfind('}') + 1
            if json_start != -1 and json_end > json_start:
                json_str = content[json_start:json_end]
                result = json.loads(json_str)
                if 'response' not in result:
                    result['response'] = content
                return result
        except json.JSONDecodeError:
            pass
        
        return {
            "action": "generate",
            "objects": [],
            "response": content
        }
    
    def _mock_process(self, user_message: str, session_state: Dict) -> Dict:
        """模拟处理（无 API Key 时使用）"""
        current_stage = session_state.get('current_stage', 0)
        
        if current_stage == 0:
            return {
                'response': f'好的，我来帮您画"{user_message}"！请告诉我以下细节：\n1. 具体是什么样子？（颜色、姿态等）\n2. 什么风格？（简笔画/素描/卡通/写实）\n3. 黑白还是彩色？\n4. 背景要求？\n\n请一次性回答这些问题！',
                'current_stage': 1,
                'completed': False,
                'generation_method': 'qwen-image'
            }
        else:
            return {
                'response': '太好了！正在为您生成草图...',
                'current_stage': 2,
                'completed': True,
                'final_prompt': f'A simple sketch of {user_message}, hand-drawn style',
                'generation_method': 'qwen-image'
            }
    
    def _mock_parse(self, user_message: str) -> Dict:
        """模拟解析（无 API Key 时使用）"""
        if any(word in user_message for word in ['改', '修改', '调整', '变大', '变小', '移动']):
            return {
                "action": "modify",
                "modifications": [{
                    "target": "detected_object",
                    "operation": "adjust",
                    "description": user_message
                }],
                "response": f"我理解您想要修改草图：{user_message}"
            }
        else:
            return {
                "action": "generate",
                "objects": [{
                    "type": "object",
                    "attributes": {
                        "style": "simple",
                        "stroke_count": 16
                    }
                }],
                "response": f"好的，我来为您绘制：{user_message}"
            }
