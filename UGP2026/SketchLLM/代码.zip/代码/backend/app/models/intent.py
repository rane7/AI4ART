from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum

class ActionType(Enum):
    GENERATE = "generate"
    MODIFY = "modify"
    ADD = "add"
    DELETE = "delete"
    ADJUST = "adjust"

@dataclass
class ObjectAttribute:
    size: Optional[str] = None
    position: Optional[str] = None
    style: Optional[str] = "simple"
    scale: Optional[float] = 1.0
    position_x: Optional[int] = None
    position_y: Optional[int] = None

@dataclass
class SketchObject:
    type: str
    attributes: ObjectAttribute = field(default_factory=ObjectAttribute)
    description: Optional[str] = None

@dataclass
class Modification:
    target: str
    operation: str
    value: Optional[str] = None
    description: Optional[str] = None

@dataclass
class Intent:
    action: ActionType
    objects: List[SketchObject] = field(default_factory=list)
    modifications: List[Modification] = field(default_factory=list)
    response: str = ""
    raw_text: str = ""
    
    def to_dict(self) -> Dict:
        return {
            "action": self.action.value,
            "objects": [
                {
                    "type": obj.type,
                    "attributes": {
                        k: v for k, v in vars(obj.attributes).items() if v is not None
                    }
                }
                for obj in self.objects
            ],
            "modifications": [
                {
                    "target": mod.target,
                    "operation": mod.operation,
                    "value": mod.value,
                    "description": mod.description
                }
                for mod in self.modifications
            ],
            "response": self.response,
            "raw_text": self.raw_text
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Intent':
        action = ActionType(data.get('action', 'generate'))
        
        objects = []
        for obj_data in data.get('objects', []):
            attrs = ObjectAttribute(**obj_data.get('attributes', {}))
            objects.append(SketchObject(
                type=obj_data.get('type', 'object'),
                attributes=attrs,
                description=obj_data.get('description')
            ))
        
        modifications = []
        for mod_data in data.get('modifications', []):
            modifications.append(Modification(
                target=mod_data.get('target', ''),
                operation=mod_data.get('operation', ''),
                value=mod_data.get('value'),
                description=mod_data.get('description')
            ))
        
        return cls(
            action=action,
            objects=objects,
            modifications=modifications,
            response=data.get('response', ''),
            raw_text=data.get('raw_text', '')
        )
