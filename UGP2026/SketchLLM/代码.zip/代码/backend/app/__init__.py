from flask import Flask, request, jsonify
from flask_cors import CORS
import os

def create_app():
    app = Flask(__name__)
    app.config.from_object('backend.config.Config')
    
    CORS(app)
    
    upload_folder = app.config.get('UPLOAD_FOLDER', 'outputs/sketches')
    session_folder = app.config.get('SESSION_FOLDER', 'outputs/sessions')
    os.makedirs(upload_folder, exist_ok=True)
    os.makedirs(session_folder, exist_ok=True)
    
    from backend.app.routes import chat, sketch, session as session_route
    from backend.app.services.session_manager import session_manager
    
    @app.route('/api/set-generation-method', methods=['POST'])
    def set_generation_method_direct():
        data = request.get_json()
        session_id = data.get('session_id', '')
        method = data.get('method', 'clipascene')
        
        if method not in ['clipascene', 'qwen-image']:
            return jsonify({'error': '无效的生成方法'}), 400
        
        session = session_manager.get_or_create(session_id)
        session.set_generation_method(method)
        session.reset_intent_state()
        
        return jsonify({
            'session_id': session.id,
            'generation_method': method,
            'message': f'已选择生成方法：{"CLIPascene 算法" if method == "clipascene" else "通义万相 画图模型"}'
        })
    
    app.register_blueprint(chat.bp)
    app.register_blueprint(sketch.bp)
    app.register_blueprint(session_route.bp)
    
    return app
