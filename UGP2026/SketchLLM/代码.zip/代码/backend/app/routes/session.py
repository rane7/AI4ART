from flask import Blueprint, request, jsonify
from backend.app.services.session_manager import session_manager

bp = Blueprint('session', __name__, url_prefix='/api/session')

@bp.route('/create', methods=['POST'])
def create():
    session = session_manager.create()
    return jsonify({
        'session_id': session.id
    })

@bp.route('/set-generation-method', methods=['POST'])
def set_generation_method():
    data = request.get_json()
    session_id = data.get('session_id', '')
    method = data.get('method', 'clipascene')
    
    if method not in ['clipascene', 'qwen-image']:
        return jsonify({'error': '无效的生成方法'}), 400
    
    session = session_manager.get_or_create(session_id)
    session.set_generation_method(method)
    session.reset_intent_state()
    
    return jsonify({
        'session_id': session.id,
        'generation_method': method,
        'message': f'已选择生成方法：{"CLIPascene 算法" if method == "clipascene" else "通义万相 画图模型"}'
    })

@bp.route('/<session_id>', methods=['GET'])
def get(session_id):
    session = session_manager.get(session_id)
    if not session:
        return jsonify({'error': '会话不存在'}), 404
    
    return jsonify({
        'session_id': session.id,
        'created_at': session.created_at,
        'sketch_history': session.get_sketch_history(),
        'state': session.get_intent_state()
    })

@bp.route('/<session_id>', methods=['DELETE'])
def delete(session_id):
    success = session_manager.delete(session_id)
    if not success:
        return jsonify({'error': '会话不存在'}), 404
    return jsonify({'success': True})
