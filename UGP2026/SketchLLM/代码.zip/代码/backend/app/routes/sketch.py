from flask import Blueprint, request, jsonify, send_file, current_app
from backend.app.services.sketch_generator import SketchGenerator
from backend.app.services.session_manager import session_manager
from backend.app.services.aliyun_image_service import AliyunImageService
import os
import base64
import traceback

bp = Blueprint('sketch', __name__, url_prefix='/api/sketch')
sketch_generator = SketchGenerator()
aliyun_image_service = AliyunImageService()

@bp.route('/generate', methods=['POST'])
def generate():
    try:
        data = request.get_json()
        intent = data.get('intent', {})
        session_id = data.get('session_id', '')
        method = data.get('method', 'clipascene')
        prompt = data.get('prompt', '')
        
        print(f"[DEBUG] generate called: method={method}, prompt={prompt}, session_id={session_id}")
        
        session = session_manager.get_or_create(session_id)
        
        if method == 'qwen-image' and prompt:
            print(f"[DEBUG] Calling aliyun_image_service with prompt: {prompt}")
            result = aliyun_image_service.generate_image(prompt)
            print(f"[DEBUG] aliyun result: success={result.get('success')}, error={result.get('error')}")
            
            if result.get('success'):
                image_base64 = result.get('image_base64')
                
                if image_base64:
                    upload_folder = current_app.config.get('UPLOAD_FOLDER', 'outputs/sketches')
                    image_path = os.path.join(upload_folder, f'{session.id}_current.png')
                    
                    img_data = base64.b64decode(image_base64)
                    with open(image_path, 'wb') as f:
                        f.write(img_data)
                    
                    session.update_sketch(image_base64)
                    
                    return jsonify({
                        'image_base64': image_base64,
                        'image_url': f'/api/sketch/file/{session.id}_current.png',
                        'method': 'qwen-image',
                        'prompt': prompt
                    })
                else:
                    return jsonify({
                        'error': '生成图像失败：未获取到图像数据',
                        'method': 'qwen-image'
                    }), 500
            else:
                return jsonify({
                    'error': result.get('error', '生成图像失败'),
                    'method': 'qwen-image'
                }), 500
        else:
            svg_content = sketch_generator.generate(intent)
            
            upload_folder = current_app.config.get('UPLOAD_FOLDER', 'outputs/sketches')
            svg_path = os.path.join(upload_folder, f'{session.id}_current.svg')
            with open(svg_path, 'w', encoding='utf-8') as f:
                f.write(svg_content)
            
            session.update_sketch(svg_content)
            
            return jsonify({
                'svg': svg_content,
                'svg_url': f'/api/sketch/file/{session.id}_current.svg',
                'method': 'clipascene'
            })
    except Exception as e:
        print(f"[ERROR] generate failed: {str(e)}")
        traceback.print_exc()
        return jsonify({
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500

@bp.route('/modify', methods=['POST'])
def modify():
    try:
        data = request.get_json()
        modifications = data.get('modifications', [])
        session_id = data.get('session_id', '')
        
        session = session_manager.get(session_id)
        if not session:
            return jsonify({'error': '会话不存在'}), 404
        
        current_svg = session.get_current_sketch()
        if not current_svg:
            return jsonify({'error': '没有可修改的草图'}), 400
        
        new_svg = sketch_generator.modify(current_svg, modifications)
        
        upload_folder = current_app.config.get('UPLOAD_FOLDER', 'outputs/sketches')
        svg_path = os.path.join(upload_folder, f'{session.id}_current.svg')
        with open(svg_path, 'w', encoding='utf-8') as f:
            f.write(new_svg)
        
        session.update_sketch(new_svg)
        
        return jsonify({
            'svg': new_svg,
            'svg_url': f'/api/sketch/file/{session.id}_current.svg'
        })
    except Exception as e:
        print(f"[ERROR] modify failed: {str(e)}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@bp.route('/file/<filename>', methods=['GET'])
def get_file(filename):
    try:
        upload_folder = current_app.config.get('UPLOAD_FOLDER', 'outputs/sketches')
        file_path = os.path.join(upload_folder, filename)
        if not os.path.exists(file_path):
            return jsonify({'error': '文件不存在'}), 404
        
        if filename.endswith('.png') or filename.endswith('.jpg') or filename.endswith('.jpeg'):
            return send_file(file_path, mimetype='image/png')
        else:
            return send_file(file_path, mimetype='image/svg+xml')
    except Exception as e:
        return jsonify({'error': str(e)}), 500
