from flask import Blueprint, request, jsonify
from backend.app.services.llm_service import LLMService
from backend.app.services.session_manager import session_manager
from backend.app.services.intent_understanding_service import IntentUnderstandingService

bp = Blueprint('chat', __name__, url_prefix='/api/chat')
llm_service = LLMService()
intent_service = IntentUnderstandingService()

@bp.route('/message', methods=['POST'])
def send_message():
    data = request.get_json()
    user_message = data.get('message', '')
    session_id = data.get('session_id', '')
    image_base64 = data.get('image', None)
    
    if not user_message and not image_base64:
        return jsonify({'error': '消息或图片不能同时为空'}), 400
    
    session = session_manager.get_or_create(session_id)
    
    session_state = session.get_intent_state()
    session_state['history'] = session.get_history()
    session_state['generation_method'] = session.get_generation_method()
    
    intent_result = intent_service.process_message(user_message, session_state, image_base64)
    
    if intent_result.get('conversation_history'):
        session_state['conversation_history'] = intent_result['conversation_history']
    
    session.update_intent_state({
        'current_stage': intent_result.get('current_stage', 0),
        'collected_details': intent_result.get('collected_details', {}),
        'conversation_history': intent_result.get('conversation_history', [])
    })
    
    if image_base64:
        session.add_message('user', f"[上传图片] {user_message}" if user_message else "[上传图片]", image=image_base64)
    else:
        session.add_message('user', user_message)
    session.add_message('assistant', intent_result.get('response', ''))
    
    return jsonify({
        'session_id': session.id,
        'intent': intent_result,
        'response': intent_result.get('response', ''),
        'completed': intent_result.get('completed', False),
        'generation_method': intent_result.get('generation_method', 'clipascene'),
        'final_prompt': intent_result.get('final_prompt', '')
    })

@bp.route('/set-method', methods=['POST'])
def set_generation_method():
    data = request.get_json()
    session_id = data.get('session_id', '')
    method = data.get('method', 'clipascene')
    
    if method not in ['clipascene', 'qwen-image']:
        return jsonify({'error': '无效的生成方法'}), 400
    
    session = session_manager.get_or_create(session_id)
    session.set_generation_method(method)
    session.reset_intent_state()
    
    return jsonify({
        'session_id': session.id,
        'generation_method': method,
        'message': f'已选择生成方法：{"CLIPascene 算法" if method == "clipascene" else "通义万相 画图模型"}'
    })

@bp.route('/history/<session_id>', methods=['GET'])
def get_history(session_id):
    session = session_manager.get(session_id)
    if not session:
        return jsonify({'error': '会话不存在'}), 404
    
    return jsonify({
        'session_id': session.id,
        'history': session.get_history(),
        'state': session.get_intent_state()
    })
