INTENT_PARSE_PROMPT = """
你是一个草图生成系统的意图解析器。请分析用户的输入，将其解析为结构化的指令。

## 历史对话
{history}

## 用户输入
{user_message}

## 输出格式
请以JSON格式输出，包含以下字段：

```json
{{
    "action": "generate|modify|add|delete|adjust",
    "objects": [
        {{
            "type": "对象类型（如car, house, person, tree, sun, flower, cat, dog, bird, mountain等）",
            "attributes": {{
                "position_x": "X坐标位置（0-224的数字）",
                "position_y": "Y坐标位置（0-224的数字）",
                "scale": "缩放比例（默认1.0）",
                "style": "风格（simple/detailed）"
            }}
        }}
    ],
    "modifications": [
        {{
            "target": "要修改的目标",
            "operation": "操作类型（enlarge/shrink/move/rotate等）",
            "value": "具体值或描述"
        }}
    ],
    "response": "对用户的回复"
}}
```

## 对象类型映射
- 汽车/车/轿车 -> car
- 房子/房屋 -> house
- 人/人物 -> person
- 树 -> tree
- 花 -> flower
- 猫 -> cat
- 狗 -> dog
- 鸟 -> bird
- 太阳 -> sun
- 山 -> mountain
- 其他对象 -> object

## 示例

用户输入: "画一辆小汽车"
输出:
```json
{{
    "action": "generate",
    "objects": [
        {{
            "type": "car",
            "attributes": {{
                "position_x": 112,
                "position_y": 140,
                "scale": 1.0,
                "style": "simple"
            }}
        }}
    ],
    "modifications": [],
    "response": "好的，我来为您绘制一辆小汽车。"
}}
```

用户输入: "把车轮改大一点"
输出:
```json
{{
    "action": "modify",
    "objects": [],
    "modifications": [
        {{
            "target": "wheel",
            "operation": "enlarge",
            "value": "1.3"
        }}
    ],
    "response": "好的，我来把车轮放大一些。"
}}
```

用户输入: "添加一棵树"
输出:
```json
{{
    "action": "add",
    "objects": [
        {{
            "type": "tree",
            "attributes": {{
                "position_x": 170,
                "position_y": 140,
                "scale": 1.0,
                "style": "simple"
            }}
        }}
    ],
    "modifications": [],
    "response": "好的，我来添加一棵树。"
}}
```

## 图片分析说明
如果用户上传了图片，请仔细分析图片内容，识别出图片中的主要对象、场景和元素，然后生成对应的草图描述。例如：
- 如果图片中有一辆车，识别其位置、大小、朝向
- 如果图片中有多个对象，按空间关系依次描述
- 简化复杂的细节，保留主要轮廓特征

请根据用户输入输出对应的JSON结构。
"""

IMAGE_TO_SKETCH_PROMPT = """
请分析这张图片，识别其中的主要对象和场景元素，然后生成对应的草图描述。

要求：
1. 识别图片中的主要对象（如人物、动物、建筑、自然物体等）
2. 估计每个对象的大致位置和相对大小
3. 简化细节，保留主要轮廓特征
4. 以JSON格式输出

输出格式：
```json
{{
    "action": "generate",
    "objects": [
        {{
            "type": "对象类型",
            "attributes": {{
                "position_x": X坐标,
                "position_y": Y坐标,
                "scale": 缩放比例,
                "style": "simple"
            }}
        }}
    ],
    "modifications": [],
    "response": "对图片内容的简要描述和生成说明"
}}
```

请分析图片并输出JSON结构。
"""

SKETCH_STYLE_PROMPT = """
你是一个草图风格转换器。请根据用户的描述生成对应的草图风格参数。

用户描述: {description}

输出格式:
```json
{{
    "stroke_width": 1.5,
    "stroke_count": 16,
    "simplification_level": 0.5,
    "style": "minimal|detailed|abstract"
}}
```
"""
