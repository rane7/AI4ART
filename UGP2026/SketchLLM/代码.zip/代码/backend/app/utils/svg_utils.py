import svgpathtools
import re
from typing import List, Tuple, Optional
import xml.etree.ElementTree as ET

def parse_svg(svg_content: str) -> dict:
    root = ET.fromstring(svg_content)
    
    paths = []
    for path_elem in root.iter('{http://www.w3.org/2000/svg}path'):
        d = path_elem.get('d', '')
        paths.append({
            'd': d,
            'stroke': path_elem.get('stroke', 'black'),
            'stroke_width': path_elem.get('stroke-width', '1'),
            'fill': path_elem.get('fill', 'none')
        })
    
    return {
        'paths': paths,
        'viewBox': root.get('viewBox', '0 0 224 224')
    }

def extract_strokes(svg_content: str) -> List[List[Tuple[float, float]]]:
    strokes = []
    root = ET.fromstring(svg_content)
    
    for path_elem in root.iter('{http://www.w3.org/2000/svg}path'):
        d = path_elem.get('d', '')
        points = parse_path_d(d)
        if points:
            strokes.append(points)
    
    return strokes

def parse_path_d(d: str) -> List[Tuple[float, float]]:
    points = []
    
    d = d.replace(',', ' ')
    
    commands = re.findall(r'([MLHVCSQTAZ])([^MLHVCSQTAZ]*)', d, re.IGNORECASE)
    
    current_x, current_y = 0.0, 0.0
    
    for cmd, args_str in commands:
        args = [float(x) for x in args_str.strip().split() if x]
        
        if cmd.upper() == 'M':
            if len(args) >= 2:
                current_x, current_y = args[0], args[1]
                points.append((current_x, current_y))
        elif cmd.upper() == 'L':
            if len(args) >= 2:
                current_x, current_y = args[0], args[1]
                points.append((current_x, current_y))
        elif cmd.upper() == 'H':
            if args:
                current_x = args[0]
                points.append((current_x, current_y))
        elif cmd.upper() == 'V':
            if args:
                current_y = args[0]
                points.append((current_x, current_y))
        elif cmd.upper() == 'C':
            if len(args) >= 6:
                current_x, current_y = args[4], args[5]
                points.append((current_x, current_y))
        elif cmd.upper() == 'S':
            if len(args) >= 4:
                current_x, current_y = args[2], args[3]
                points.append((current_x, current_y))
        elif cmd.upper() == 'Z':
            if points:
                points.append(points[0])
    
    return points

def strokes_to_svg(strokes: List[List[Tuple[float, float]]], 
                   width: int = 224, height: int = 224,
                   stroke_width: float = 1.5) -> str:
    svg_parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}">',
        f'<rect width="100%" height="100%" fill="white"/>'
    ]
    
    for stroke in strokes:
        if len(stroke) < 2:
            continue
        
        d = f"M {stroke[0][0]:.1f} {stroke[0][1]:.1f}"
        for point in stroke[1:]:
            d += f" L {point[0]:.1f} {point[1]:.1f}"
        
        svg_parts.append(
            f'<path d="{d}" stroke="black" fill="none" stroke-width="{stroke_width}"/>'
        )
    
    svg_parts.append('</svg>')
    return '\n'.join(svg_parts)

def transform_stroke(stroke: List[Tuple[float, float]], 
                     scale: float = 1.0, 
                     offset_x: float = 0, 
                     offset_y: float = 0,
                     rotation: float = 0) -> List[Tuple[float, float]]:
    import math
    
    transformed = []
    cos_r = math.cos(rotation)
    sin_r = math.sin(rotation)
    
    for x, y in stroke:
        new_x = x * cos_r - y * sin_r
        new_y = x * sin_r + y * cos_r
        new_x = new_x * scale + offset_x
        new_y = new_y * scale + offset_y
        transformed.append((new_x, new_y))
    
    return transformed

def get_stroke_bounds(stroke: List[Tuple[float, float]]) -> Tuple[float, float, float, float]:
    if not stroke:
        return 0, 0, 0, 0
    
    xs = [p[0] for p in stroke]
    ys = [p[1] for p in stroke]
    
    return min(xs), min(ys), max(xs), max(ys)

def get_stroke_center(stroke: List[Tuple[float, float]]) -> Tuple[float, float]:
    if not stroke:
        return 0, 0
    
    xs = [p[0] for p in stroke]
    ys = [p[1] for p in stroke]
    
    return (min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2
