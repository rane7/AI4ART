# Backend for Interactive Sketch Generation System

## Setup

1. Create virtual environment and install dependencies:
```bash
python -m venv venv
.\venv\Scripts\activate  # Windows
pip install -r requirements.txt
```

2. Set environment variables:
```bash
# Create .env file
ZHIPU_API_KEY=your_api_key_here
```

3. Run the server:
```bash
python run.py
```

## API Endpoints

### Chat
- `POST /api/chat/message` - Send a message
- `GET /api/chat/history/<session_id>` - Get chat history

### Sketch
- `POST /api/sketch/generate` - Generate a new sketch
- `POST /api/sketch/modify` - Modify existing sketch
- `GET /api/sketch/file/<filename>` - Get sketch file

### Session
- `POST /api/session/create` - Create new session
- `GET /api/session/<session_id>` - Get session info
- `DELETE /api/session/<session_id>` - Delete session
