import os

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    ZHIPU_API_KEY = os.environ.get('ZHIPU_API_KEY', '')
    ZHIPU_MODEL = os.environ.get('ZHIPU_MODEL', 'glm-4.6v')
    
    ALIYUN_API_KEY = os.environ.get('ALIYUN_API_KEY', '')
    ALIYUN_API_BASE = os.environ.get('ALIYUN_API_BASE', 'https://dashscope.aliyuncs.com/api/v1')
    ALIYUN_IMAGE_MODEL = os.environ.get('ALIYUN_IMAGE_MODEL', 'wanx-v1')
    
    UPLOAD_FOLDER = os.path.join(BASE_DIR, 'outputs', 'sketches')
    SESSION_FOLDER = os.path.join(BASE_DIR, 'outputs', 'sessions')
    
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'svg'}
