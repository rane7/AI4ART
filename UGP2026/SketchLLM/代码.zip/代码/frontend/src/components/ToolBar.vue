<script setup lang="ts">
import { useSketchStore } from '../stores/sketch'
import { useChatStore } from '../stores/chat'

const sketchStore = useSketchStore()
const chatStore = useChatStore()

const quickCommands = [
  { label: '画一辆车', command: '画一辆小汽车' },
  { label: '画一栋房子', command: '画一栋房子' },
  { label: '画一棵树', command: '画一棵树' },
  { label: '画一个人', command: '画一个人物' },
  { label: '画一只猫', command: '画一只猫' },
  { label: '画一个太阳', command: '画一个太阳' }
]

const sendQuickCommand = async (command: string) => {
  await chatStore.sendMessage(command)
  
  if (chatStore.currentIntent) {
    const action = chatStore.currentIntent.action
    if (action === 'generate' || action === 'add') {
      await sketchStore.generateSketch(chatStore.currentIntent)
    }
  }
}

const clearCanvas = () => {
  sketchStore.clearSketch()
  chatStore.clearMessages()
}
</script>

<template>
  <div class="tool-bar panel">
    <div class="panel-header">
      工具栏
    </div>
    
    <div class="panel-content">
      <div class="section">
        <h4>快捷命令</h4>
        <div class="quick-commands">
          <button
            v-for="cmd in quickCommands"
            :key="cmd.label"
            class="btn btn-secondary quick-btn"
            @click="sendQuickCommand(cmd.command)"
            :disabled="chatStore.isLoading"
          >
            {{ cmd.label }}
          </button>
        </div>
      </div>
      
      <div class="section">
        <h4>操作</h4>
        <button 
          class="btn btn-secondary full-width"
          @click="clearCanvas"
        >
          清空画布
        </button>
      </div>
      
      <div class="section" v-if="sketchStore.history.length > 0">
        <h4>历史记录</h4>
        <div class="history-list">
          <div 
            v-for="(item, index) in sketchStore.history.slice(-5).reverse()"
            :key="index"
            class="history-item"
          >
            <span>版本 {{ sketchStore.history.length - index }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.tool-bar {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.panel-content {
  flex: 1;
  overflow-y: auto;
}

.section {
  margin-bottom: 20px;
}

.section h4 {
  font-size: 12px;
  color: #888;
  margin-bottom: 10px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.quick-commands {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.quick-btn {
  text-align: left;
  padding: 10px 12px;
}

.full-width {
  width: 100%;
}

.history-list {
  display: flex;
  flex-direction: column;
  gap: 6px;
}

.history-item {
  padding: 8px 10px;
  background: #f5f5f5;
  border-radius: 6px;
  font-size: 12px;
  color: #666;
}
</style>
