<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import { useSketchStore } from '../stores/sketch'

const sketchStore = useSketchStore()
const canvasRef = ref<HTMLDivElement | null>(null)

const svgContent = computed(() => sketchStore.currentSvg)
const imageContent = computed(() => sketchStore.currentImage)
const isQwenImage = computed(() => sketchStore.isQwenImage)
const methodLabel = computed(() => isQwenImage.value ? '通义万相' : 'CLIPascene')

const imageSrc = computed(() => {
  if (imageContent.value) {
    return `data:image/png;base64,${imageContent.value}`
  }
  return ''
})

watch(() => sketchStore.currentImage, (newVal) => {
  console.log('Image updated, length:', newVal?.length || 0)
})
</script>

<template>
  <div class="sketch-canvas panel">
    <div class="panel-header">
      <span>草图预览</span>
      <div class="header-actions">
        <span v-if="sketchStore.hasSketch" class="method-badge">
          {{ methodLabel }}
        </span>
        <button 
          v-if="sketchStore.hasSketch"
          class="btn btn-secondary download-btn"
          @click="sketchStore.downloadSketch"
        >
          下载
        </button>
      </div>
    </div>
    
    <div class="canvas-container" ref="canvasRef">
      <div v-if="sketchStore.isLoading" class="loading-overlay">
        <div class="spinner"></div>
        <p>生成中...</p>
      </div>
      
      <div v-else-if="!sketchStore.hasSketch" class="placeholder">
        <div class="placeholder-icon">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M12 19l7-7 3 3-7 7-3-3z"/>
            <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/>
            <path d="M2 2l7.586 7.586"/>
            <circle cx="11" cy="11" r="2"/>
          </svg>
        </div>
        <p>在左侧输入描述开始创作</p>
        <p class="placeholder-hint">选择"通义万相"可体验 AI 智能生成</p>
      </div>
      
      <div 
        v-else-if="isQwenImage && imageSrc" 
        class="image-container"
      >
        <img 
          :src="imageSrc" 
          alt="生成的草图" 
          class="generated-image"
          @error="console.error('Image load error')"
        />
      </div>
      
      <div 
        v-else-if="svgContent" 
        class="svg-container"
        v-html="svgContent"
      ></div>
    </div>
  </div>
</template>

<style scoped>
.sketch-canvas {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 12px;
}

.method-badge {
  font-size: 12px;
  padding: 4px 10px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-radius: 12px;
}

.download-btn {
  padding: 4px 12px;
  font-size: 12px;
}

.canvas-container {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #fafafa;
  border-radius: 8px;
  margin: 16px;
  overflow: hidden;
  position: relative;
}

.placeholder {
  text-align: center;
  color: #999;
}

.placeholder-icon {
  margin-bottom: 12px;
  color: #ccc;
}

.placeholder p {
  font-size: 14px;
  margin: 4px 0;
}

.placeholder-hint {
  font-size: 12px !important;
  color: #aaa;
  margin-top: 8px !important;
}

.loading-overlay {
  text-align: center;
  color: #667eea;
}

.spinner {
  width: 40px;
  height: 40px;
  border: 3px solid #f3f3f3;
  border-top: 3px solid #667eea;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  margin: 0 auto 12px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.svg-container {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.svg-container :deep(svg) {
  max-width: 100%;
  max-height: 100%;
}

.image-container {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
}

.generated-image {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}
</style>
