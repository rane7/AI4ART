<script setup lang="ts">
import { ref, onMounted, nextTick, watch } from 'vue'
import { useChatStore } from '../stores/chat'
import { useSketchStore } from '../stores/sketch'

const chatStore = useChatStore()
const sketchStore = useSketchStore()

const inputMessage = ref('')
const messagesContainer = ref<HTMLElement | null>(null)
const fileInput = ref<HTMLInputElement | null>(null)
const selectedImage = ref<string | null>(null)
const selectedImagePreview = ref<string | null>(null)
const isGeneratingSketch = ref(false)

const handleImageSelect = (event: Event) => {
  const target = event.target as HTMLInputElement
  const file = target.files?.[0]
  
  if (file) {
    if (!file.type.startsWith('image/')) {
      alert('请选择图片文件')
      return
    }
    
    if (file.size > 10 * 1024 * 1024) {
      alert('图片大小不能超过10MB')
      return
    }
    
    const reader = new FileReader()
    reader.onload = (e) => {
      const result = e.target?.result as string
      selectedImage.value = result.split(',')[1]
      selectedImagePreview.value = result
    }
    reader.readAsDataURL(file)
  }
}

const clearSelectedImage = () => {
  selectedImage.value = null
  selectedImagePreview.value = null
  if (fileInput.value) {
    fileInput.value.value = ''
  }
}

const triggerFileInput = () => {
  fileInput.value?.click()
}

const selectGenerationMethod = async (method: 'clipascene' | 'qwen-image') => {
  try {
    await chatStore.setGenerationMethod(method)
    sketchStore.clearSketch()
  } catch (error) {
    console.error('Failed to set generation method:', error)
  }
}

const sendMessage = async () => {
  if (!inputMessage.value.trim() && !selectedImage.value) return
  
  const message = inputMessage.value.trim()
  const imageBase64 = selectedImage.value
  
  inputMessage.value = ''
  clearSelectedImage()
  
  await chatStore.sendMessage(message, imageBase64)
  
  if (chatStore.isIntentCompleted) {
    await generateSketchWithMethod()
  } else if (chatStore.currentIntent && chatStore.generationMethod === 'clipascene') {
    const action = chatStore.currentIntent.action
    
    if (action === 'generate' || action === 'add') {
      await sketchStore.generateSketch(chatStore.currentIntent, 'clipascene', '', chatStore.sessionId)
    } else if (action === 'modify') {
      await sketchStore.modifySketch(chatStore.currentIntent.modifications, chatStore.sessionId)
    }
  }
  
  await nextTick()
  scrollToBottom()
}

const generateSketchWithMethod = async () => {
  isGeneratingSketch.value = true
  
  try {
    if (chatStore.generationMethod === 'qwen-image' && chatStore.finalPrompt) {
      await sketchStore.generateSketch(
        chatStore.currentIntent,
        'qwen-image',
        chatStore.finalPrompt,
        chatStore.sessionId
      )
    } else if (chatStore.currentIntent) {
      await sketchStore.generateSketch(chatStore.currentIntent, 'clipascene', '', chatStore.sessionId)
    }
  } catch (error) {
    console.error('Failed to generate sketch:', error)
  } finally {
    isGeneratingSketch.value = false
  }
}

const scrollToBottom = () => {
  if (messagesContainer.value) {
    messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight
  }
}

onMounted(() => {
  chatStore.initSession()
})

watch(
  () => chatStore.messages.length,
  () => {
    nextTick(() => scrollToBottom())
  }
)
</script>

<template>
  <div class="chat-panel panel">
    <div class="panel-header">
      对话面板
    </div>
    
    <div class="method-selector">
      <button
        class="method-btn"
        :class="{ active: chatStore.generationMethod === 'clipascene' }"
        @click="selectGenerationMethod('clipascene')"
        :disabled="chatStore.isLoading"
      >
        🎨 CLIPascene
      </button>
      <button
        class="method-btn"
        :class="{ active: chatStore.generationMethod === 'qwen-image' }"
        @click="selectGenerationMethod('qwen-image')"
        :disabled="chatStore.isLoading"
      >
        ✨ 通义万相
      </button>
    </div>
    
    <div class="messages-container" ref="messagesContainer">
      <div 
        v-for="(msg, index) in chatStore.messages" 
        :key="index"
        :class="['message', msg.role]"
      >
        <div v-if="msg.image" class="message-image">
          <img :src="`data:image/jpeg;base64,${msg.image}`" alt="上传的图片" />
        </div>
        <div class="message-content">
          {{ msg.content }}
        </div>
      </div>
      
      <div v-if="chatStore.isLoading" class="message assistant loading">
        <div class="message-content">
          <span class="loading-dots">思考中...</span>
        </div>
      </div>
      
      <div v-if="isGeneratingSketch" class="message assistant loading">
        <div class="message-content">
          <span class="loading-dots">正在生成草图...</span>
        </div>
      </div>
    </div>
    
    <div v-if="selectedImagePreview" class="image-preview-container">
      <img :src="selectedImagePreview" alt="预览" class="image-preview" />
      <button class="clear-image-btn" @click="clearSelectedImage">×</button>
    </div>
    
    <div class="input-area">
      <input
        type="file"
        ref="fileInput"
        accept="image/*"
        style="display: none"
        @change="handleImageSelect"
      />
      <button 
        class="btn btn-icon upload-btn"
        @click="triggerFileInput"
        :disabled="chatStore.isLoading || isGeneratingSketch"
        title="上传图片"
      >
        📷
      </button>
      <input
        v-model="inputMessage"
        type="text"
        class="input"
        :placeholder="selectedImagePreview ? '描述这张图片...' : '描述你想要的草图...'"
        @keyup.enter="sendMessage"
        :disabled="chatStore.isLoading || isGeneratingSketch"
      />
      <button 
        class="btn btn-primary send-btn"
        @click="sendMessage"
        :disabled="chatStore.isLoading || isGeneratingSketch || (!inputMessage.trim() && !selectedImage)"
      >
        发送
      </button>
    </div>
  </div>
</template>

<style scoped>
.chat-panel {
  height: 100%;
  display: flex;
  flex-direction: column;
}

.method-selector {
  display: flex;
  gap: 8px;
  padding: 12px;
  border-bottom: 1px solid #eee;
  background: #fafafa;
}

.method-btn {
  flex: 1;
  padding: 10px 16px;
  border: 2px solid #ddd;
  border-radius: 8px;
  background: white;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s;
  color: #666;
}

.method-btn:hover:not(:disabled) {
  border-color: #667eea;
  color: #667eea;
}

.method-btn.active {
  border-color: #667eea;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
}

.method-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.messages-container {
  flex: 1;
  overflow-y: auto;
  padding: 16px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.message {
  max-width: 85%;
  padding: 10px 14px;
  border-radius: 12px;
  font-size: 14px;
  line-height: 1.5;
}

.message.user {
  align-self: flex-end;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border-bottom-right-radius: 4px;
}

.message.assistant {
  align-self: flex-start;
  background: #f0f0f0;
  color: #333;
  border-bottom-left-radius: 4px;
}

.message-image {
  margin-bottom: 8px;
}

.message-image img {
  max-width: 200px;
  max-height: 150px;
  border-radius: 8px;
  object-fit: contain;
}

.loading-dots {
  color: #888;
}

.image-preview-container {
  position: relative;
  padding: 8px 12px;
  border-top: 1px solid #eee;
  display: flex;
  align-items: center;
  justify-content: center;
}

.image-preview {
  max-height: 100px;
  max-width: 150px;
  border-radius: 8px;
  object-fit: contain;
  border: 2px solid #667eea;
}

.clear-image-btn {
  position: absolute;
  top: 0;
  right: 12px;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: #ff4444;
  color: white;
  border: none;
  cursor: pointer;
  font-size: 16px;
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
}

.clear-image-btn:hover {
  background: #cc0000;
}

.input-area {
  padding: 12px;
  border-top: 1px solid #eee;
  display: flex;
  gap: 8px;
}

.upload-btn {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  padding: 0;
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f0f0f0;
  border: 1px solid #ddd;
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.2s;
}

.upload-btn:hover:not(:disabled) {
  background: #e0e0e0;
}

.upload-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.send-btn {
  flex-shrink: 0;
}
</style>
