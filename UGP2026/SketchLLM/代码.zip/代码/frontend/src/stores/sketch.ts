import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import * as api from '../api'

interface SketchHistory {
  svg?: string
  image_base64?: string
  timestamp: string
  method: 'clipascene' | 'qwen-image'
}

export const useSketchStore = defineStore('sketch', () => {
  const currentSvg = ref<string>('')
  const currentImage = ref<string>('')
  const currentMethod = ref<'clipascene' | 'qwen-image'>('clipascene')
  const history = ref<SketchHistory[]>([])
  const isLoading = ref(false)

  const hasSketch = computed(() => !!currentSvg.value || !!currentImage.value)
  const isQwenImage = computed(() => currentMethod.value === 'qwen-image')

  async function generateSketch(intent: any, method: 'clipascene' | 'qwen-image' = 'clipascene', prompt: string = '', sessionId: string = '') {
    isLoading.value = true
    
    try {
      const response = await api.generateSketch(intent, method, prompt, sessionId)
      
      if (response.method === 'qwen-image') {
        currentImage.value = response.image_base64 || ''
        currentSvg.value = ''
        history.value.push({
          image_base64: response.image_base64,
          timestamp: new Date().toISOString(),
          method: 'qwen-image'
        })
      } else {
        currentSvg.value = response.svg
        currentImage.value = ''
        history.value.push({
          svg: response.svg,
          timestamp: new Date().toISOString(),
          method: 'clipascene'
        })
      }
      
      currentMethod.value = response.method || method
    } catch (error) {
      console.error('Failed to generate sketch:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  async function modifySketch(modifications: any[], sessionId: string = '') {
    if (!currentSvg.value) return
    
    isLoading.value = true
    
    try {
      const response = await api.modifySketch(modifications, sessionId)
      currentSvg.value = response.svg
      currentImage.value = ''
      currentMethod.value = 'clipascene'
      history.value.push({
        svg: response.svg,
        timestamp: new Date().toISOString(),
        method: 'clipascene'
      })
    } catch (error) {
      console.error('Failed to modify sketch:', error)
      throw error
    } finally {
      isLoading.value = false
    }
  }

  function clearSketch() {
    currentSvg.value = ''
    currentImage.value = ''
    history.value = []
    currentMethod.value = 'clipascene'
  }

  function downloadSketch() {
    if (isQwenImage.value && currentImage.value) {
      const blob = base64ToBlob(currentImage.value, 'image/png')
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `sketch_${Date.now()}.png`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } else if (currentSvg.value) {
      const blob = new Blob([currentSvg.value], { type: 'image/svg+xml' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `sketch_${Date.now()}.svg`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    }
  }

  function base64ToBlob(base64: string, mimeType: string): Blob {
    const byteCharacters = atob(base64)
    const byteArrays = []
    
    for (let offset = 0; offset < byteCharacters.length; offset += 512) {
      const slice = byteCharacters.slice(offset, offset + 512)
      const byteNumbers = new Array(slice.length)
      for (let i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i)
      }
      const byteArray = new Uint8Array(byteNumbers)
      byteArrays.push(byteArray)
    }
    
    return new Blob(byteArrays, { type: mimeType })
  }

  return {
    currentSvg,
    currentImage,
    currentMethod,
    history,
    isLoading,
    hasSketch,
    isQwenImage,
    generateSketch,
    modifySketch,
    clearSketch,
    downloadSketch
  }
})
