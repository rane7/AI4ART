import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import * as api from '../api'

interface Message {
  role: 'user' | 'assistant'
  content: string
  timestamp?: string
  image?: string
}

interface Intent {
  action: string
  objects: any[]
  modifications: any[]
  response: string
  completed?: boolean
  generation_method?: 'clipascene' | 'qwen-image'
  final_prompt?: string
  current_stage?: number
  collected_details?: any
}

export const useChatStore = defineStore('chat', () => {
  const messages = ref<Message[]>([])
  const sessionId = ref<string>('')
  const isLoading = ref(false)
  const currentIntent = ref<Intent | null>(null)
  const generationMethod = ref<'clipascene' | 'qwen-image'>('clipascene')
  const isIntentCompleted = ref(false)
  const finalPrompt = ref<string>('')

  const messageCount = computed(() => messages.value.length)

  async function initSession() {
    try {
      const response = await api.createSession()
      sessionId.value = response.session_id
    } catch (error) {
      console.error('Failed to create session:', error)
    }
  }

  async function setGenerationMethod(method: 'clipascene' | 'qwen-image') {
    if (!sessionId.value) {
      await initSession()
    }
    
    generationMethod.value = method
    isIntentCompleted.value = false
    finalPrompt.value = ''
    currentIntent.value = null
    messages.value = []
    
    try {
      await api.setGenerationMethod(sessionId.value, method)
    } catch (error) {
      console.error('Failed to set generation method:', error)
    }
    
    return {
      session_id: sessionId.value,
      generation_method: method,
      message: `已选择生成方法：${method === 'clipascene' ? 'CLIPascene 算法' : '通义万相 画图模型'}`
    }
  }

  async function sendMessage(content: string, imageBase64: string | null = null) {
    if ((!content.trim() && !imageBase64) || isLoading.value) return

    if (!sessionId.value) {
      await initSession()
    }

    messages.value.push({
      role: 'user',
      content: imageBase64 ? `[上传图片] ${content}` : content,
      timestamp: new Date().toISOString(),
      image: imageBase64 || undefined
    })

    isLoading.value = true

    try {
      const response = await api.sendMessage(sessionId.value, content, imageBase64)
      
      if (response.session_id) {
        sessionId.value = response.session_id
      }
      
      currentIntent.value = response.intent
      isIntentCompleted.value = response.completed || false
      finalPrompt.value = response.final_prompt || ''
      if (response.generation_method) {
        generationMethod.value = response.generation_method
      }
      
      messages.value.push({
        role: 'assistant',
        content: response.response || '好的，我来处理您的请求。',
        timestamp: new Date().toISOString()
      })
    } catch (error) {
      console.error('Failed to send message:', error)
      messages.value.push({
        role: 'assistant',
        content: '抱歉，处理您的请求时出现了错误。',
        timestamp: new Date().toISOString()
      })
    } finally {
      isLoading.value = false
    }
  }

  function clearMessages() {
    messages.value = []
    currentIntent.value = null
    isIntentCompleted.value = false
    finalPrompt.value = ''
  }

  return {
    messages,
    sessionId,
    isLoading,
    currentIntent,
    generationMethod,
    isIntentCompleted,
    finalPrompt,
    messageCount,
    initSession,
    setGenerationMethod,
    sendMessage,
    clearMessages
  }
})
