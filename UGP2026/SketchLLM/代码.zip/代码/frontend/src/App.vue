<script setup lang="ts">
import ChatPanel from './components/ChatPanel.vue'
import SketchCanvas from './components/SketchCanvas.vue'
import ToolBar from './components/ToolBar.vue'
</script>

<template>
  <div class="app-container">
    <header class="app-header">
      <h1>交互式草图生成系统</h1>
      <p class="subtitle">大语言模型驱动下的智能草图创作</p>
    </header>
    
    <main class="app-main">
      <div class="left-panel">
        <ChatPanel />
      </div>
      
      <div class="center-panel">
        <SketchCanvas />
      </div>
      
      <div class="right-panel">
        <ToolBar />
      </div>
    </main>
  </div>
</template>

<style scoped>
.app-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
  background: #f5f5f5;
}

.app-header {
  padding: 16px 24px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  text-align: center;
}

.app-header h1 {
  margin: 0;
  font-size: 24px;
  font-weight: 600;
}

.subtitle {
  margin: 4px 0 0;
  font-size: 14px;
  opacity: 0.9;
}

.app-main {
  flex: 1;
  display: flex;
  padding: 16px;
  gap: 16px;
  overflow: hidden;
}

.left-panel {
  width: 320px;
  flex-shrink: 0;
}

.center-panel {
  flex: 1;
  min-width: 0;
}

.right-panel {
  width: 200px;
  flex-shrink: 0;
}
</style>
