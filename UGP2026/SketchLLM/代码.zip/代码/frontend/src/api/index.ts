import axios from 'axios'

const API_BASE = '/api'

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json'
  }
})

export async function createSession() {
  const response = await api.post('/session/create')
  return response.data
}

export async function getSession(sessionId: string) {
  const response = await api.get(`/session/${sessionId}`)
  return response.data
}

export async function deleteSession(sessionId: string) {
  const response = await api.delete(`/session/${sessionId}`)
  return response.data
}

export async function sendMessage(sessionId: string, message: string, imageBase64: string | null = null) {
  const payload: any = {
    session_id: sessionId,
    message: message
  }
  if (imageBase64) {
    payload.image = imageBase64
  }
  const response = await api.post('/chat/message', payload)
  return response.data
}

export async function setGenerationMethod(sessionId: string, method: 'clipascene' | 'qwen-image') {
  const response = await api.post('/set-generation-method', {
    session_id: sessionId,
    method: method
  })
  return response.data
}

export async function getChatHistory(sessionId: string) {
  const response = await api.get(`/chat/history/${sessionId}`)
  return response.data
}

export async function generateSketch(intent: any, method: 'clipascene' | 'qwen-image' = 'clipascene', prompt: string = '', sessionId: string = '') {
  const payload: any = {
    intent: intent,
    method: method,
    session_id: sessionId
  }
  if (prompt) {
    payload.prompt = prompt
  }
  const response = await api.post('/sketch/generate', payload)
  return response.data
}

export async function modifySketch(modifications: any[], sessionId: string = '') {
  const response = await api.post('/sketch/modify', {
    modifications: modifications,
    session_id: sessionId
  })
  return response.data
}

export function getSketchUrl(filename: string) {
  return `${API_BASE}/sketch/file/${filename}`
}
